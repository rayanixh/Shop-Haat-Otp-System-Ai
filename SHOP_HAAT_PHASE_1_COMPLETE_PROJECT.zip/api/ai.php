<?php
/**
 * AI Auto Work — admin AJAX endpoint. Always returns JSON.
 *
 * Every action requires: an authenticated admin session, a valid CSRF token and
 * validated input. All provider calls happen here, server-side, so the API key
 * never reaches a browser.
 */
declare(strict_types=1);
define('SH_JSON_CONTEXT', true);
require_once dirname(__DIR__) . '/config/config.php';

if (sh_db_config() === null || !sh_is_locked()) {
    sh_json(['success' => false, 'error' => 'The store is not installed yet.'], 503);
}
try { sh_db(); } catch (Throwable $e) {
    sh_log_exception($e, 'api-ai-db');
    sh_json(['success' => false, 'error' => 'Service temporarily unavailable.'], 503);
}

require_once SH_ROOT . '/includes/admin-auth.php';
require_once SH_ROOT . '/includes/admin-perms.php';
require_once SH_ROOT . '/ai/AIManager.php';

sh_session_start();
$admin = sh_require_admin();          // redirects/401s anyone who is not an admin
$adminId = (int)($admin['id'] ?? 0);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sh_json(['success' => false, 'error' => 'POST required.'], 405);
}
sh_csrf_require();

if (!sh_ai_installed()) {
    sh_json(['success' => false, 'error' => 'AI Auto Work is not installed. Open AI Settings and run the installer.'], 400);
}

$action = sh_post('action');

/** Simple per-admin throttle so a stuck loop cannot burn credit. */
function sh_ai_throttle(int $adminId, int $perMinute = 30): bool
{
    try {
        $n = (int)sh_val(
            'SELECT COUNT(*) FROM ai_generations WHERE admin_id = ? AND created_at > (NOW() - INTERVAL 1 MINUTE)',
            [$adminId], 0
        );
        return $n < $perMinute;
    } catch (Throwable $e) {
        return true;
    }
}

try {
    switch ($action) {

        /* ---------- single generation (preview only, nothing saved) ------- */
        case 'generate': {
            if (!sh_ai_throttle($adminId)) {
                sh_json(['success' => false, 'error' => 'Too many requests in the last minute. Please wait a moment.'], 429);
            }
            $task = sh_post('task');
            $refId = sh_int($_POST['ref_id'] ?? 0);
            $allowed = ['title', 'description', 'short', 'tags', 'seo', 'category',
                        'image_prompt', 'image', 'category_content', 'blog'];
            if (!in_array($task, $allowed, true)) {
                sh_json(['success' => false, 'error' => 'Unknown generation task.'], 400);
            }
            if ($task !== 'blog' && $refId <= 0) {
                sh_json(['success' => false, 'error' => 'Choose an item first.'], 400);
            }

            $extra = [];
            if ($task === 'blog') {
                $extra = [
                    'topic'    => mb_substr(sh_post('topic'), 0, 300),
                    'audience' => mb_substr(sh_post('audience'), 0, 200),
                    'keywords' => mb_substr(sh_post('keywords'), 0, 300),
                    'length'   => max(200, min(2000, sh_int($_POST['length'] ?? 700))),
                ];
                if (trim($extra['topic']) === '') {
                    sh_json(['success' => false, 'error' => 'Enter a topic for the blog post.'], 400);
                }
            }
            if ($task === 'image') {
                $extra['prompt'] = mb_substr(sh_post('prompt'), 0, 3000);
                // Image AI lets the admin pick a compatible provider/model explicitly.
                $pid = sh_int($_POST['provider_id'] ?? 0);
                if ($pid > 0) {
                    $extra['provider_id'] = $pid;
                    $extra['model'] = mb_substr(sh_post('model'), 0, 120);
                }
            }

            $res = sh_ai_run_task($task, $refId, $adminId, $extra);
            if (empty($res['ok'])) {
                sh_json(['success' => false, 'error' => (string)$res['error'], 'capability' => !empty($res['capability'])]);
            }

            $payload = ['success' => true, 'task' => $task, 'data' => $res['data'], 'via' => $res['via'] ?? null];
            if ($task === 'image' && !empty($res['data']['file'])) {
                $payload['url'] = sh_url('uploads/products/' . rawurlencode((string)$res['data']['file']));
            }
            // Generation never writes to the product. The administrator reviews
            // the result and uses the explicit Save action (or the AI product
            // review form) — no background write happens here.
            sh_json($payload);
        }

        /* ---------- Complete Product draft (nothing is saved) ------------- */
        case 'product_draft': {
            // Writing the product may happen later through the normal Save
            // Product form, so the matching product permission is required here.
            if (!sh_admin_can('ai.use')) {
                sh_json(['success' => false, 'error' => 'You do not have permission to use AI Auto Work.'], 403);
            }
            $productId = sh_int($_POST['product_id'] ?? 0);
            // A new product needs create rights; an existing one needs edit rights.
            $needed = $productId > 0 ? 'products.edit' : 'products.create';
            if (!sh_admin_can($needed)) {
                sh_json(['success' => false, 'error' => 'You do not have permission to ' . ($productId > 0 ? 'edit this product.' : 'create products.')], 403);
            }
            if (!sh_ai_throttle($adminId, 20)) {
                sh_json(['success' => false, 'error' => 'Too many AI requests in the last minute. Please wait a moment.'], 429);
            }

            $name = mb_substr(trim(sh_post('name')), 0, 190);
            if ($name === '') {
                sh_json(['success' => false, 'error' => 'Enter the product name first.'], 400);
            }

            // Only fields the panel really offers, each a bounded string.
            $field = sh_post('field');
            $allowedFields = ['', 'title', 'short', 'description', 'specifications',
                              'category', 'sku', 'seo', 'image_alt'];
            if (!in_array($field, $allowedFields, true)) {
                sh_json(['success' => false, 'error' => 'Unknown field to regenerate.'], 400);
            }

            $knownIn = json_decode((string)($_POST['known'] ?? ''), true);
            $known = [];
            if (is_array($knownIn)) {
                foreach (['model', 'size', 'material', 'colour', 'dimensions', 'notes', 'specs'] as $k) {
                    if (!isset($knownIn[$k]) || !is_scalar($knownIn[$k])) { continue; }
                    $known[$k] = mb_substr(trim((string)$knownIn[$k]), 0, $k === 'specs' ? 2000 : 600);
                }
            }

            // The reference image: the file the admin has just selected (not
            // uploaded yet), else the product's saved image on the edit screen.
            $image = null;
            if (!empty($_FILES['image']['name'])) {
                $up = sh_ai_draft_image_from_upload($_FILES['image']);
                if (empty($up['ok'])) {
                    sh_json(['success' => false, 'error' => (string)($up['error'] ?? 'The image could not be read.')], 400);
                }
                $image = $up['image'];
            }

            // A full draft is the normal path for AI Auto Work: the product name
            // is the only required input. "want_image" asks the server to create
            // the featured photo with the configured image model.
            $wantImage = !empty($_POST['want_image']) || $field === '';
            $wantGallery = !empty($_POST['want_gallery']);

            $res = sh_ai_product_draft([
                'name'              => $name,
                'short_description' => mb_substr(trim(sh_post('short_description')), 0, 300),
                'known'             => $known,
                'field'             => $field,
                'product_id'        => $productId,
                'image'             => $image,
                'want_image'        => $wantImage,
                'want_gallery'      => $wantGallery,
            ], $adminId);

            if (empty($res['ok'])) {
                sh_json(['success' => false, 'error' => (string)$res['error']]);
            }

            $image = $res['image'] ?? null;
            $gallery = $res['gallery'] ?? [];

            sh_json([
                'success'        => true,
                'task'           => 'product_full',
                'field'          => $field,
                'data'           => $res['data'],
                'via'            => $res['via'] ?? null,
                'image_used'     => !empty($res['image_used']),
                'image_supplied' => !empty($res['image_supplied']),
                // The truth about the image: ok=false with the real reason is a
                // failure the interface must show, never a quiet success.
                'image'          => $image === null ? null : [
                    'ok'    => !empty($image['ok']),
                    'file'  => (string)($image['file'] ?? ''),
                    'url'   => (string)($image['url'] ?? ''),
                    'error' => (string)($image['error'] ?? ''),
                ],
                'gallery'        => array_map(static fn($g) => [
                    'file' => (string)($g['file'] ?? ''),
                    'url'  => (string)($g['url'] ?? ''),
                ], (array)$gallery),
            ]);
        }

        /* ---------- generate just the featured image for a draft ---------- */
        case 'product_image': {
            if (!sh_admin_can('products.create')) {
                sh_json(['success' => false, 'error' => 'You do not have permission to create products.'], 403);
            }
            if (!sh_ai_throttle($adminId, 20)) {
                sh_json(['success' => false, 'error' => 'Too many requests in the last minute. Please wait a moment.'], 429);
            }
            $name = mb_substr(trim(sh_post('name')), 0, 190);
            if ($name === '') {
                sh_json(['success' => false, 'error' => 'Enter the product name first.'], 400);
            }
            $draft = ['name' => $name, 'title' => $name];
            $decoded = json_decode((string)($_POST['data'] ?? ''), true);
            if (is_array($decoded)) {
                foreach (['title', 'short_description', 'category_name'] as $k) {
                    if (isset($decoded[$k]) && is_scalar($decoded[$k])) {
                        $draft[$k] = mb_substr((string)$decoded[$k], 0, 300);
                    }
                }
            }
            $image = sh_ai_generate_product_image($draft, $adminId);
            if (empty($image['ok'])) {
                sh_json(['success' => false, 'error' => (string)($image['error'] ?? 'The image could not be generated.')], 422);
            }
            sh_json(['success' => true, 'file' => (string)$image['file'], 'url' => (string)$image['url']]);
        }

        /* ---------- save a reviewed full product (one transaction) -------- */
        case 'save_product': {
            if (!sh_admin_can('products.create')) {
                sh_json(['success' => false, 'error' => 'You do not have permission to create products.'], 403);
            }
            if (!sh_ai_throttle($adminId, 20)) {
                sh_json(['success' => false, 'error' => 'Too many requests in the last minute. Please wait a moment.'], 429);
            }

            $raw = (string)($_POST['data'] ?? '');
            $data = json_decode($raw, true);
            if (!is_array($data)) {
                sh_json(['success' => false, 'error' => 'Nothing to save. Review the draft first.'], 400);
            }

            $res = sh_ai_save_full_product($data, $adminId);
            if (empty($res['ok'])) {
                sh_json(array_filter([
                    'success' => false,
                    'error'   => (string)($res['error'] ?? 'The product could not be saved.'),
                    'fields'  => $res['fields'] ?? null,
                ], static fn($v) => $v !== null), 422);
            }

            // This is an internal editor link returned only after this endpoint's
            // admin session, CSRF and product-create checks. In custom-route mode
            // sh_url() maps it to the active route; public storefront/API responses
            // must never include that route.
            sh_json([
                'success'       => true,
                'id'            => (int)$res['id'],
                'slug'          => (string)($res['slug'] ?? ''),
                'url'            => (string)($res['url'] ?? ''),
                'admin_url'     => (string)($res['admin_url'] ?? ''),
                'already_saved' => !empty($res['already_saved']),
                'image_url'     => (string)($res['image_url'] ?? ''),
                'tags'          => $res['tags'] ?? [],
                'gallery'       => $res['gallery'] ?? [],
                'verify'        => $res['verify'] ?? [],
                'message'       => (string)($res['message'] ?? 'Product saved.'),
            ]);
        }

        /* ---------- persist an approved result ---------------------------- */
        case 'save': {
            $task = sh_post('task');
            $refId = sh_int($_POST['ref_id'] ?? 0);
            $raw = (string)($_POST['data'] ?? '');
            $data = json_decode($raw, true);
            if (!is_array($data)) {
                sh_json(['success' => false, 'error' => 'Nothing to save.'], 400);
            }
            $allowed = ['title', 'description', 'short', 'tags', 'seo', 'category', 'image', 'category_content'];
            if (!in_array($task, $allowed, true) || $refId <= 0) {
                sh_json(['success' => false, 'error' => 'Unknown save target.'], 400);
            }
            // Generating is one permission; writing is another. Without this an
            // operator with only ai.use could edit products they cannot open.
            $needed = $task === 'category_content' ? 'catalog.manage' : 'products.edit';
            if (!sh_admin_can($needed)) {
                sh_json(['success' => false, 'error' => 'You do not have permission to change this item.'], 403);
            }
            $res = sh_ai_apply($task, $refId, $data, $adminId);
            if (empty($res['ok'])) { sh_json(['success' => false, 'error' => (string)$res['error']]); }
            sh_log_line('admin', 'AI applied "' . $task . '" to #' . $refId . ' by ' . ($admin['email'] ?? ''));
            sh_json(['success' => true, 'message' => 'Saved.']);
        }

        /* ---------- blog: save as draft or publish ------------------------ */
        case 'save_blog': {
            $data = json_decode((string)($_POST['data'] ?? ''), true);
            if (!is_array($data)) { sh_json(['success' => false, 'error' => 'Nothing to save.'], 400); }
            // Publishing requires BOTH an explicit request and the setting enabled.
            $wants = !empty($_POST['publish']);
            $publish = $wants && sh_ai_config()['auto_publish'];
            $res = sh_ai_save_blog($data, $adminId, $publish);
            if (empty($res['ok'])) { sh_json(['success' => false, 'error' => (string)$res['error']]); }
            $msg = $res['status'] === 'published'
                ? 'Post published.'
                : ($wants && !$publish
                    ? 'Saved as a draft. Enable "Allow auto publish" in AI Settings to publish directly.'
                    : 'Saved as a draft.');
            sh_json(['success' => true, 'message' => $msg, 'id' => $res['id'], 'status' => $res['status']]);
        }

        /* ---------- create a category the AI suggested -------------------- */
        case 'create_category': {
            $name = trim(mb_substr(sh_post('name'), 0, 120));
            $productId = sh_int($_POST['ref_id'] ?? 0);
            if ($name === '') { sh_json(['success' => false, 'error' => 'The category needs a name.'], 400); }
            $slug = sh_slug($name);
            if ($slug === '') { sh_json(['success' => false, 'error' => 'Could not build a URL slug.'], 400); }
            $exists = sh_one('SELECT id FROM categories WHERE slug = ? OR name = ? LIMIT 1', [$slug, $name]);
            if ($exists !== null) {
                // Never create a duplicate; reuse what is already there.
                $catId = (int)$exists['id'];
            } else {
                $catId = (int)sh_insert('categories', [
                    'name' => $name, 'slug' => $slug, 'icon' => 'grid',
                    'sort_order' => (int)sh_val('SELECT COALESCE(MAX(sort_order),0)+1 FROM categories', [], 1),
                    'status' => 1,
                ]);
            }
            if ($productId > 0) { sh_query('UPDATE products SET category_id = ? WHERE id = ?', [$catId, $productId]); }
            sh_json(['success' => true, 'category_id' => $catId,
                     'message' => $exists !== null ? 'That category already existed and was applied.' : 'Category created and applied.']);
        }

        /* ---------- bulk queue -------------------------------------------- */
        case 'bulk_queue': {
            $ids = $_POST['products'] ?? [];
            $tasks = $_POST['tasks'] ?? [];
            if (is_string($ids)) { $ids = explode(',', $ids); }
            if (is_string($tasks)) { $tasks = explode(',', $tasks); }
            if (!is_array($ids) || !is_array($tasks)) {
                sh_json(['success' => false, 'error' => 'Select products and tasks.'], 400);
            }
            $res = sh_ai_queue_batch($ids, $tasks, $adminId, sh_int($_POST['provider_id'] ?? 0), mb_substr(sh_post('model'), 0, 120));
            if (empty($res['ok'])) { sh_json(['success' => false, 'error' => (string)$res['error']]); }
            sh_json(['success' => true] + $res);
        }

        case 'bulk_process': {
            $batch = preg_replace('/[^a-z0-9]/i', '', sh_post('batch_id')) ?? '';
            if ($batch === '') { sh_json(['success' => false, 'error' => 'Unknown batch.'], 400); }
            $progress = sh_ai_process_batch($batch, $adminId);
            sh_json(['success' => true] + $progress);
        }

        case 'bulk_status': {
            $batch = preg_replace('/[^a-z0-9]/i', '', sh_post('batch_id')) ?? '';
            if ($batch === '') { sh_json(['success' => false, 'error' => 'Unknown batch.'], 400); }
            sh_json(['success' => true] + sh_ai_batch_progress($batch));
        }

        case 'bulk_retry': {
            $batch = preg_replace('/[^a-z0-9]/i', '', sh_post('batch_id')) ?? '';
            if ($batch === '') { sh_json(['success' => false, 'error' => 'Unknown batch.'], 400); }
            $res = sh_ai_retry_failed($batch);
            if (empty($res['ok'])) { sh_json(['success' => false, 'error' => (string)$res['error']]); }
            sh_json(['success' => true] + $res);
        }

        /* ---------- providers: verify the credentials really work ---------
         * "success" means the test RAN and produced a real answer. The outcome
         * is "ok": a rejected key is a completed test, not a failed request, so
         * the browser can render the provider's actual state without treating
         * the HTTP call itself as broken. No secret is ever returned.
         */
        case 'test_connection': {
            $pid = sh_int($_POST['provider_id'] ?? 0);
            if ($pid <= 0) { sh_json(['success' => false, 'error' => 'Choose a provider to test.'], 400); }
            if (sh_ai_provider_row($pid) === null) { sh_json(['success' => false, 'error' => 'That provider no longer exists.'], 404); }
            $res = sh_ai_provider_test($pid);
            $code = (string)($res['code'] ?? (!empty($res['ok']) ? 'connected' : 'failed'));
            sh_json([
                'success'    => true,
                'ok'         => !empty($res['ok']),
                'code'       => $code,
                'state'      => sh_ai_test_state_label($code),
                'tone'       => sh_ai_test_state_tone($code),
                'status'     => (int)($res['status'] ?? 0),
                'message'    => (string)($res['message'] ?? ($res['ok'] ? 'Connected.' : 'The test failed.')),
                'next'       => (string)($res['next'] ?? ''),
                'model'      => (string)($res['model'] ?? ''),
                'tested_at'  => (string)($res['tested_at'] ?? date('Y-m-d H:i:s')),
            ]);
        }

        /* ---------- providers: import the live model catalogue ------------ */
        case 'sync_models': {
            $pid = sh_int($_POST['provider_id'] ?? 0);
            if ($pid <= 0) { sh_json(['success' => false, 'error' => 'Unknown provider.'], 400); }
            $res = sh_ai_models_sync($pid);
            if (empty($res['ok'])) { sh_json(['success' => false, 'error' => (string)$res['error']]); }
            $models = [];
            foreach (sh_ai_models($pid) as $m) {
                $models[] = ['id' => (string)$m['model_id'], 'name' => (string)$m['name'],
                             'text' => (int)$m['output_text'], 'image' => (int)$m['output_image'], 'enabled' => (int)$m['status']];
            }
            sh_json(['success' => true, 'count' => (int)$res['count'], 'models' => $models,
                     'message' => (int)$res['count'] . ' models loaded from the provider.']);
        }

        /* ---------- models: enabled models of one provider (no secrets) --- */
        case 'provider_models': {
            $pid = sh_int($_POST['provider_id'] ?? 0);
            $kind = sh_post('kind') === 'image' ? 'image' : 'text';
            $models = [];
            foreach (sh_ai_models($pid, true) as $m) {
                if ($kind === 'image' ? empty($m['output_image']) : empty($m['output_text'])) { continue; }
                $models[] = ['id' => (string)$m['model_id'], 'name' => (string)$m['name']];
            }
            sh_json(['success' => true, 'models' => $models]);
        }

        /* ---------- product picker for the AI screens --------------------- */
        case 'search_products': {
            $q = trim(sh_post('q'));
            $rows = $q === ''
                ? sh_all('SELECT id, name, image FROM products ORDER BY id DESC LIMIT 20')
                : sh_all('SELECT id, name, image FROM products WHERE name LIKE ? OR sku LIKE ? ORDER BY name ASC LIMIT 20',
                    ['%' . $q . '%', '%' . $q . '%']);
            $out = [];
            foreach ($rows as $r) {
                $out[] = ['id' => (int)$r['id'], 'name' => (string)$r['name'],
                          'image' => sh_product_image($r['image'])];
            }
            sh_json(['success' => true, 'products' => $out]);
        }
    }

    sh_json(['success' => false, 'error' => 'Unknown action.'], 400);

} catch (Throwable $e) {
    // Never leak a stack trace, SQL or a path to the browser.
    sh_log_exception($e, 'api-ai');
    sh_json(['success' => false, 'error' => 'Something went wrong. The error has been logged.'], 500);
}
