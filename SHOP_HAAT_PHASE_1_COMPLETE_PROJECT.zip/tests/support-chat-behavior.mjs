/**
 * Support chat widget behaviour harness.
 *
 * Drives the REAL assets/js/support-chat.js inside jsdom against fixture
 * markup mirroring includes/support-widget.php (kept honest by source
 * checks below) with a scripted fetch() standing in for api/support.php,
 * and asserts the customer-visible rules:
 *
 *   - opening the panel reveals it once (a single start call) as a
 *     viewport-fixed, bottom-anchored popup; the message log alone scrolls
 *     internally and the page is never scroll-pinned or scroll-locked;
 *   - every request carries the CSRF token and an idempotent client_msg_id,
 *     and a failed send offers Retry reusing that same id;
 *   - message bodies render as TEXT (an XSS payload stays inert) and only
 *     same-origin store links become anchors;
 *   - AI-generated, automatic and human replies are labelled differently —
 *     nothing deterministic is ever shown as "AI assistant";
 *   - handoff, polling (with dedupe), a new conversation and Escape all
 *     behave, and a rate-limit answer is explained instead of failing hard.
 *
 * Test-only: the store itself still runs on plain PHP with no Node.js.
 *
 *   node tests/support-chat-behavior.mjs
 *
 * Environment:
 *   SH_JSDOM_PATH         path to a jsdom installation (default: require("jsdom"))
 *   SH_SC_REQUIRE_JSDOM   "1" fails instead of skipping when jsdom is missing
 */

import { createRequire } from 'node:module';
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = dirname(fileURLToPath(import.meta.url));
const ROOT = dirname(HERE);
const require_ = createRequire(import.meta.url);

let JSDOM = null;
try {
	const path = process.env.SH_JSDOM_PATH;
	({ JSDOM } = path ? require_(path) : require_('jsdom'));
} catch {
	JSDOM = null;
}
if (!JSDOM) {
	const msg = 'jsdom is not installed, so the support-chat behaviour harness did not run.';
	if (process.env.SH_SC_REQUIRE_JSDOM === '1') {
		console.error('::error title=Support chat harness::' + msg);
		process.exit(1);
	}
	console.log('SKIP  ' + msg);
	console.log('      install it with:  npm i --no-save jsdom@26.1.0');
	process.exit(0);
}

let passed = 0;
const failures = [];
function check(name, condition, detail) {
	if (condition) { passed += 1; console.log('  ok  ' + name); }
	else { failures.push(name + (detail ? ' — ' + detail : '')); console.log('FAIL  ' + name + (detail ? ' — ' + detail : '')); }
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/* Fixture fidelity: every hook the script needs must exist in the shipped
 * markup, and the panel must be viewport-fixed and bottom-anchored. */
const widgetPhp = readFileSync(join(ROOT, 'includes/support-widget.php'), 'utf8');
const appCss = readFileSync(join(ROOT, 'assets/css/app.css'), 'utf8');
const supportBackend = readFileSync(join(ROOT, 'includes/ai-support.php'), 'utf8');
const supportApi = readFileSync(join(ROOT, 'api/support.php'), 'utf8');
for (const id of ['sh-schat-fab', 'sh-schat-sheet', 'sh-schat-messages', 'sh-schat-suggest', 'sh-schat-form',
	'sh-schat-input', 'sh-schat-send', 'sh-schat-status', 'sh-schat-badge',
	'sh-schat-handoff', 'sh-schat-new', 'sh-schat-close',
	'sh-schat-menu', 'sh-schat-opt-facebook', 'sh-schat-opt-whatsapp', 'sh-schat-opt-chat']) {
	check('shipped widget markup has #' + id, widgetPhp.includes('id="' + id + '"'));
}
check('chat panel is viewport-fixed, bottom-anchored and safe-area aware',
	/\.sh-schat-sheet\s*\{[^}]*position:\s*fixed[^}]*bottom:\s*calc\(var\(--sh-schat-bottom\) \+ env\(safe-area-inset-bottom/s.test(appCss)
	&& !/\.sh-schat-sheet\s*\{[^}]*position:\s*absolute/.test(appCss));
const chatRules = appCss.match(/\.sh-schat-[^{]+\{[^}]*\}/g) || [];
const scrollingRules = chatRules.filter((r) => /overflow(-x|-y)?\s*:\s*(auto|scroll)/.test(r));
const messageScrollRule = scrollingRules.find((r) => /^\.sh-schat-messages/.test(r)) || '';
const composerScrollRule = scrollingRules.find((r) => /^\.sh-schat-input/.test(r)) || '';
check('only the message log and fixed composer textarea own internal scroll regions',
	scrollingRules.length === 2 && /overscroll-behavior:\s*contain/.test(messageScrollRule)
	&& /overflow-y:\s*auto/.test(composerScrollRule) && /resize:\s*none/.test(composerScrollRule));
const chatJs = readFileSync(join(ROOT, 'assets/js/support-chat.js'), 'utf8');
check('widget JS never pins the panel to document scroll and re-measures the viewport',
	!chatJs.includes('window.scrollY') && !chatJs.includes('form.scrollIntoView')
	&& chatJs.includes('syncViewport()') && chatJs.includes('visualViewport'));
/* Subtle composer sizing: smaller type/padding, a comfortable touch target,
 * fixed dimensions and one horizontal row on mobile. The fixed popup and the
 * two intentional internal scroll regions are asserted above. */
const composerRules = appCss.match(/\.sh-schat-(?:form|input|send|handoff)\s*\{[^}]*\}/g) || [];
const inputRule = composerRules.find((r) => r.startsWith('.sh-schat-input')) || '';
const sendRule = composerRules.find((r) => r.startsWith('.sh-schat-send')) || '';
const formRule = composerRules.find((r) => r.startsWith('.sh-schat-form')) || '';
const handoffRule = composerRules.find((r) => r.startsWith('.sh-schat-handoff')) || '';
const inputFont = Number((inputRule.match(/font-size:\s*([\d.]+)px/) || [])[1] || 0);
const sendFont = Number((sendRule.match(/font-size:\s*([\d.]+)px/) || [])[1] || 0);
const bubbleFont = Number(((appCss.match(/\.sh-schat-bubble\s*\{[^}]*\}/) || [''])[0].match(/font-size:\s*([\d.]+)px/) || [])[1] || 0);
check('input type is subtly smaller than a message bubble but still readable',
	inputFont > 0 && bubbleFont > 0 && inputFont < bubbleFont && inputFont >= 13,
	`input ${inputFont}px / bubble ${bubbleFont}px`);
check('Send button text and icon are subtly reduced, not removed',
	sendFont > 0 && sendFont < 13.8 && /\.sh-schat-send svg\s*\{[^}]*width:\s*14px/.test(appCss)
	&& widgetPhp.includes("sh_icon('send', 14)"));
check('input padding is reduced without losing a comfortable touch target',
	/padding:\s*8px 10px/.test(inputRule) && /min-height:\s*40px/.test(inputRule)
	&& /min-height:\s*40px/.test(sendRule) && /padding:\s*8px 12px/.test(sendRule));
check('Talk to a human stays visible and balanced with the smaller composer',
	/font-size:\s*12\.5px/.test(handoffRule) && /min-height:\s*32px/.test(handoffRule)
	&& widgetPhp.includes('Talk to a human') && widgetPhp.includes("sh_icon('user', 14)"));
check('input and Send remain horizontally aligned on mobile',
	/flex-wrap:\s*nowrap/.test(formRule) && /@media \(max-width: 420px\)[\s\S]{0,400}flex-wrap:\s*nowrap/.test(appCss)
	&& /justify-content:\s*center/.test(sendRule));
check('Bangla/Banglish/English placeholder and orange brand colour survive',
	widgetPhp.includes('Write in বাংলা, Banglish or English') && /\.sh-schat-input:focus\s*\{[^}]*var\(--sh-brand\)/.test(appCss));

check('the Customer Support popup has no subtitle or explanatory replacement',
	!widgetPhp.includes('sh-schat-sub') && !appCss.includes('.sh-schat-sub')
	&& !chatJs.includes('defaultSub') && !/Replies use live store data|Our support team will reply here/.test(widgetPhp + chatJs));
check('the title-only header is centered with no leftover subtitle gap',
	/\.sh-schat-head\s*\{[^}]*align-items:\s*center[^}]*margin-bottom:\s*8px/.test(appCss)
	&& /\.sh-schat-headmain h2\s*\{[^}]*margin:\s*0;/.test(appCss));
check('legacy widget API adapter maps URL-encoded sends and handoffs into the transactional support service', supportApi.includes("$action === 'send'") && supportApi.includes("$input['client_msg_id']") && supportApi.includes('sh_support_customer_send(') && supportApi.includes('sh_support_customer_handoff(') && supportApi.includes("$input['after_id']"));
check('support service has no conversation/message pruning query', !/DELETE\s+FROM\s+support_(?:conversations|messages|handoff_events)/i.test(supportBackend + supportApi));

const PAGE = `<!doctype html><html><head><title>t</title></head><body>
<button type="button" class="sh-schat-fab" id="sh-schat-fab" aria-expanded="false" aria-haspopup="menu" aria-controls="sh-schat-menu" aria-label="Open support options">
  <span class="sh-schat-badge" id="sh-schat-badge" hidden>0</span>
</button>
<div class="sh-schat-menu" id="sh-schat-menu" role="menu" aria-label="Support options" aria-hidden="true" hidden>
  <a class="sh-schat-opt" id="sh-schat-opt-facebook" role="menuitem" href="https://m.me/shophaat" target="_blank" rel="noopener noreferrer nofollow" data-channel="facebook">
    <span class="sh-schat-opt__icon sh-schat-opt__icon--messenger">f</span>
    <span class="sh-schat-opt__body"><strong>Messenger Support</strong><small>Message us on Messenger</small></span>
  </a>
  <a class="sh-schat-opt" id="sh-schat-opt-whatsapp" role="menuitem" href="https://wa.me/8801700000000?text=Hi%20ShopHaat" target="_blank" rel="noopener noreferrer nofollow" data-channel="whatsapp">
    <span class="sh-schat-opt__icon sh-schat-opt__icon--whatsapp">w</span>
    <span class="sh-schat-opt__body"><strong>WhatsApp Support</strong><small>Chat with us on WhatsApp</small></span>
  </a>
  <button type="button" class="sh-schat-opt sh-schat-opt--chat" id="sh-schat-opt-chat" role="menuitem" data-channel="chat">
    <span class="sh-schat-opt__icon sh-schat-opt__icon--chat">c</span>
    <span class="sh-schat-opt__body"><strong>AI Assistant Support</strong><small>Chat with our AI Assistant</small></span>
  </button>
</div>
<section class="sh-schat-sheet" id="sh-schat-sheet" role="dialog" aria-labelledby="sh-schat-title" data-human="0" data-config='{"endpoint":"/api/support.php","max":2000}' hidden>
  <header class="sh-schat-head"><div class="sh-schat-headmain">
    <h2 id="sh-schat-title">Customer Support</h2></div>
    <div class="sh-schat-headactions">
      <button type="button" class="sh-schat-iconbtn" id="sh-schat-new" aria-label="Start a new conversation">+</button>
      <button type="button" class="sh-schat-iconbtn" id="sh-schat-close" aria-label="Close chat">×</button>
    </div></header>
  <div class="sh-schat-messages" id="sh-schat-messages" role="log" aria-live="polite" aria-relevant="additions" aria-label="Conversation messages"></div>
  <div class="sh-schat-suggest" id="sh-schat-suggest" aria-label="Quick questions"></div>
  <form class="sh-schat-form" id="sh-schat-form">
    <label class="sh-sr-only" for="sh-schat-input">Type your message</label>
    <textarea class="sh-schat-input" id="sh-schat-input" rows="2" maxlength="2000" data-sh-no-autogrow></textarea>
    <button type="submit" class="sh-btn sh-btn-primary sh-schat-send" id="sh-schat-send">Send</button>
  </form>
  <p class="sh-schat-status" id="sh-schat-status" role="status"></p>
  <div class="sh-schat-foot"><button type="button" class="sh-schat-handoff" id="sh-schat-handoff">Talk to a human</button></div>
</section></body></html>`;

/* Scripted api/support.php ------------------------------------------------ */
const requests = [];
const server = {
	nextId: 1, msgs: [], clientIds: new Map(), failNext: null, nextReply: null, human: false,
	suggestions: ['Where is my order?', 'Delivery charge koto?'],
	push(kind, body, ai) {
		const m = { id: this.nextId++, kind, ai: !!ai, body, at: '2026-08-15 10:0' + (this.nextId % 10) + ':00' };
		this.msgs.push(m); return m;
	},
	resetConv() { this.msgs = []; this.clientIds.clear(); this.human = false; },
};
server.push('assistant', 'Welcome to ShopHaat!', false);
function convPublic(human) { return { id: 42, status: human ? 'pending' : 'open', ai_active: !human, human: !!human, lang: 'en' }; }
function json(data, ok = true, status = 200) { return Promise.resolve({ ok, status, json: () => Promise.resolve(data) }); }
function fakeFetch(url, init) {
	const p = new URLSearchParams(init.body.toString());
	const action = p.get('action');
	requests.push({ action, p });
	if (server.failNext === 'network') { server.failNext = null; return Promise.reject(new Error('offline')); }
	if (server.failNext === 'rate') { server.failNext = null; return json({ ok: false, error: 'rate_limited' }, false, 429); }
	const after = parseInt(p.get('after_id') || '0', 10) || 0;
	const fresh = () => server.msgs.filter((m) => m.id > after);
	switch (action) {
		case 'start': return json({ ok: true, conversation: convPublic(false), messages: server.msgs.slice(), suggestions: server.suggestions, max_input: 2000 });
		case 'new': server.resetConv(); server.push('assistant', 'New conversation — welcome!', false);
			return json({ ok: true, conversation: convPublic(false), messages: server.msgs.slice(), suggestions: server.suggestions });
		case 'poll': return json({ ok: true, conversation: convPublic(server.human), messages: fresh(), suggestions: server.suggestions });
		case 'handoff': server.human = true; server.push('notice', 'Your request has been passed to our support team.', false);
			return json({ ok: true, conversation: convPublic(true), messages: fresh(), suggestions: [] });
		case 'send': {
			const cmid = p.get('client_msg_id');
			if (server.clientIds.has(cmid)) {
				return json({ ok: true, duplicate: true, conversation: convPublic(server.human), messages: fresh(), suggestions: [] });
			}
			server.clientIds.set(cmid, true);
			server.push('customer', p.get('message'), false);
			if (!server.human) {
				const r = server.nextReply || { body: 'Checked: Trail Runner Shoe — ৳1,250 · in stock\n/product.php?slug=trail-runner', ai: false };
				server.nextReply = null;
				server.push('assistant', r.body, r.ai);
			}
			return json({ ok: true, conversation: convPublic(server.human), messages: fresh(), suggestions: [] });
		}
		default: return json({ ok: false, error: 'bad' }, false, 400);
	}
}

const dom = new JSDOM(PAGE, { url: 'https://shop.example.bd/', runScripts: 'outside-only' });
const { window } = dom;
// jsdom windows report hidden/prerender; a real foreground tab does not, and
// the widget rightly only polls on visibilitychange when the tab is visible.
Object.defineProperty(window.document, 'hidden', { get: () => false, configurable: true });
Object.defineProperty(window.document, 'visibilityState', { get: () => 'visible', configurable: true });
window.SH_CSRF = 'csrf-test-token';
window.fetch = fakeFetch;
window.eval(readFileSync(join(ROOT, 'assets/js/support-chat.js'), 'utf8'));
const $ = (s) => window.document.querySelector(s);
const $$ = (s) => Array.from(window.document.querySelectorAll(s));
const reqs = (a) => requests.filter((r) => r.action === a);

/* 0. Launcher menu: three options above a circular button ------------------ */
const menuEl = $('#sh-schat-menu');
const fabEl = $('#sh-schat-fab');
check('the launcher shows no "Support" text label',
	!fabEl.textContent.replace(/0/g, '').trim() || fabEl.querySelector('.sh-schat-fab-label') === null,
	JSON.stringify(fabEl.textContent.trim()));
check('the menu starts hidden and out of the accessibility tree',
	menuEl.hidden === true && menuEl.getAttribute('aria-hidden') === 'true');
check('the menu offers exactly three configured support channels',
	$$('#sh-schat-menu [role="menuitem"]').length === 3
	&& !!$('#sh-schat-opt-facebook') && !!$('#sh-schat-opt-whatsapp') && !!$('#sh-schat-opt-chat'));
check('external options are safe new-tab links to the configured destinations', (() => {
	const fb = $('#sh-schat-opt-facebook');
	const wa = $('#sh-schat-opt-whatsapp');
	return fb.tagName === 'A' && wa.tagName === 'A'
		&& fb.getAttribute('target') === '_blank' && wa.getAttribute('target') === '_blank'
		&& /noopener/.test(fb.getAttribute('rel') || '') && /noreferrer/.test(wa.getAttribute('rel') || '')
		&& fb.getAttribute('href') === 'https://m.me/shophaat'
		&& wa.getAttribute('href') === 'https://wa.me/8801700000000?text=Hi%20ShopHaat';
})());
fabEl.click();
await sleep(20);
check('the launcher opens the menu instead of jumping into the chat',
	menuEl.hidden === false && menuEl.classList.contains('is-open') && $('#sh-schat-sheet').hidden === true);
check('the launcher reports the open menu', fabEl.getAttribute('aria-expanded') === 'true' && menuEl.getAttribute('aria-hidden') === 'false');
check('opening the menu does not start a conversation', reqs('start').length === 0);
check('focus moves to the first option for keyboard users', window.document.activeElement === $('#sh-schat-opt-facebook'));
const menuOpts = $$('#sh-schat-menu [role="menuitem"]');
menuOpts[0].dispatchEvent(new window.KeyboardEvent('keydown', { key: 'ArrowDown', bubbles: true, cancelable: true }));
check('ArrowDown moves to the next option', window.document.activeElement === menuOpts[1]);
menuOpts[1].dispatchEvent(new window.KeyboardEvent('keydown', { key: 'End', bubbles: true, cancelable: true }));
check('End jumps to the last option', window.document.activeElement === menuOpts[2]);
window.document.dispatchEvent(new window.KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
check('Escape closes the menu and returns focus to the launcher',
	menuEl.classList.contains('is-open') === false && fabEl.getAttribute('aria-expanded') === 'false'
	&& window.document.activeElement === fabEl);
await sleep(300);
check('a closed menu leaves the tab order', menuEl.hidden === true && menuEl.getAttribute('aria-hidden') === 'true');
fabEl.click();
await sleep(20);
window.document.body.dispatchEvent(new window.Event('pointerdown', { bubbles: true }));
await sleep(10);
check('a press outside closes the menu without opening the chat',
	menuEl.classList.contains('is-open') === false && fabEl.getAttribute('aria-expanded') === 'false'
	&& $('#sh-schat-sheet').hidden === true);

/* 1. Open → exactly one start, panel in flow, welcome + suggestions ------- */
check('sheet starts hidden', $('#sh-schat-sheet').hidden === true);
const formEl = $('#sh-schat-form');
let pageScrollIntoViewCalls = 0;
formEl.scrollIntoView = () => { pageScrollIntoViewCalls += 1; };
fabEl.click();
await sleep(20);
$('#sh-schat-opt-chat').click();
await sleep(30);
const sheet = $('#sh-schat-sheet');
check('opening reveals the panel', sheet.hidden === false);
check('opening never writes an inline document-scroll top', sheet.style.top === '', sheet.style.top);
check('viewport metrics are applied to the fixed panel', sheet.style.getPropertyValue('--sh-schat-bottom') !== '');
check('chat replies never scroll the website behind the fixed panel', pageScrollIntoViewCalls === 0, String(pageScrollIntoViewCalls));
check('website scrolling stays unlocked and independent',
	window.document.body.style.overflow === '' && window.document.documentElement.style.overflow === '');
window.dispatchEvent(new window.Event('scroll'));
check('a document scroll event never re-pins the panel', sheet.style.top === '' && sheet.style.getPropertyValue('--sh-schat-bottom') !== '', sheet.style.top);
check('the AI Assistant option opens the existing panel and folds the menu',
	sheet.hidden === false && menuEl.classList.contains('is-open') === false
	&& fabEl.getAttribute('aria-expanded') === 'false');
check('start called once with the CSRF token', reqs('start').length === 1 && reqs('start')[0].p.get('csrf_token') === 'csrf-test-token');
check('welcome message renders', $('#sh-schat-messages').textContent.includes('Welcome to ShopHaat!'));
check('quick suggestions render', $$('#sh-schat-suggest .sh-schat-chip').length === 2);

/* 2. Suggestion click sends it, reply renders with safe link --------------- */
$$('#sh-schat-suggest .sh-schat-chip')[0].click();
await sleep(30);
check('suggestion is sent as a message', reqs('send').length >= 1 && reqs('send').at(-1).p.get('message') === 'Where is my order?');
check('send carries a UUIDv4 client_msg_id and conversation id',
	/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(reqs('send').at(-1).p.get('client_msg_id') || '') && reqs('send').at(-1).p.get('conversation_id') === '42');
check('deterministic reply is labelled Support, never AI',
	$$('.sh-schat-msg .sh-schat-who').some((w) => w.textContent === 'Support') &&
	!$$('.sh-schat-msg .sh-schat-who').some((w) => w.textContent === 'AI assistant'));
const link = $('#sh-schat-messages a.sh-schat-link');
check('same-origin product URL becomes a link', !!link && link.getAttribute('href') === '/product.php?slug=trail-runner' && link.textContent === 'View product');

/* 3. AI labelling + XSS + foreign link ------------------------------------- */
server.nextReply = { body: 'Sure! <img src=x onerror=alert(1)> see https://evil.example.com/product.php?x=1\nhttps://evil.example.com/product.php?x=1', ai: true };
$('#sh-schat-input').value = 'nike shoe ache?';
$('#sh-schat-form').requestSubmit();
await sleep(30);
check('model reply is labelled AI assistant', $$('.sh-schat-msg .sh-schat-who').some((w) => w.textContent === 'AI assistant'));
check('XSS payload renders as inert text (no elements injected)',
	$('#sh-schat-messages').querySelector('img') === null && $('#sh-schat-messages').textContent.includes('<img src=x onerror=alert(1)>'));
check('foreign-origin URL is NOT turned into a link',
	$$('#sh-schat-messages a').every((a) => !a.href.includes('evil.example.com')));

/* 4. Network failure → Retry reuses the same client_msg_id ----------------- */
server.failNext = 'network';
const sendsBefore = reqs('send').length;
$('#sh-schat-input').value = 'retry me';
$('#sh-schat-form').requestSubmit();
await sleep(30);
const retryBtn = $('.sh-schat-msg.is-failed .sh-schat-retry');
check('failed send keeps the message and offers Retry', !!retryBtn);
check('failure is explained in the status line', $('#sh-schat-status').textContent.includes('Retry'));
retryBtn.click();
await sleep(30);
check('retry reuses the same client_msg_id (server dedupes)',
	reqs('send').length === sendsBefore + 2 &&
	reqs('send').at(-1).p.get('client_msg_id') === reqs('send').at(-2).p.get('client_msg_id'));

/* 5. Rate limit is explained ------------------------------------------------ */
server.failNext = 'rate';
$('#sh-schat-input').value = 'flood';
$('#sh-schat-form').requestSubmit();
await sleep(30);
check('rate limit message asks the customer to wait', $('#sh-schat-status').textContent.includes('wait a moment'));

/* 6. Poll appends agent reply once (dedupe by id) --------------------------- */
server.push('agent', 'Agent here — sorted!', false);
window.document.dispatchEvent(new window.Event('visibilitychange'));
await sleep(30);
check('polled agent reply renders as Support agent',
	$$('.sh-schat-msg .sh-schat-who').some((w) => w.textContent === 'Support agent') &&
	$('#sh-schat-messages').textContent.includes('Agent here — sorted!'));
const countAfterPoll = $$('#sh-schat-messages .sh-schat-msg').length;
window.document.dispatchEvent(new window.Event('visibilitychange'));
await sleep(30);
check('repeated polls never duplicate a message', $$('#sh-schat-messages .sh-schat-msg').length === countAfterPoll);

/* 7. Handoff switches the panel to human mode -------------------------------- */
$('#sh-schat-handoff').click();
await sleep(30);
check('handoff posts to the API', reqs('handoff').length === 1);
check('handoff hides the button and records human mode without a replacement subtitle',
	$('#sh-schat-handoff').hidden === true && $('#sh-schat-sheet').getAttribute('data-human') === '1'
	&& !$('#sh-schat-sheet').querySelector('.sh-schat-sub'));
check('handoff notice renders as a system line', !!$('.sh-schat-notice'));
check('handoff uses a UUIDv4 idempotency key', /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(reqs('handoff')[0].p.get('client_msg_id') || ''));
const noticeCountAtHandoff = $$('#sh-schat-messages .sh-schat-notice').length;
const customerCountAtHandoff = server.msgs.filter((m) => m.kind === 'customer').length;
const aiCountAtHandoff = $$('#sh-schat-messages .sh-schat-msg.is-assistant').length;
$('#sh-schat-input').value = 'I have one more question for the support agent.';
$('#sh-schat-form').requestSubmit();
await sleep(30);
check('human-mode follow-up is saved in the same thread without AI or a repeated notice', server.msgs.filter((m) => m.kind === 'customer').length === customerCountAtHandoff + 1 && $$('#sh-schat-messages .sh-schat-notice').length === noticeCountAtHandoff && $$('#sh-schat-messages .sh-schat-msg.is-assistant').length === aiCountAtHandoff && $('#sh-schat-messages').textContent.includes('I have one more question for the support agent.'));

/* 8. New conversation resets --------------------------------------------------- */
$('#sh-schat-new').click();
await sleep(30);
check('new conversation clears the old thread',
	$('#sh-schat-messages').textContent.includes('New conversation — welcome!') &&
	!$('#sh-schat-messages').textContent.includes('Agent here — sorted!'));

/* 9. Escape closes; reopening does not re-start ---------------------------------- */
window.document.dispatchEvent(new window.KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
check('Escape closes the panel', sheet.hidden === true && $('#sh-schat-fab').getAttribute('aria-expanded') === 'false');
fabEl.click();
await sleep(20);
$('#sh-schat-opt-chat').click();
await sleep(20);
check('reopening from the menu does not create a second start call', reqs('start').length === 1);
check('Enter submits the message', (() => {
	$('#sh-schat-input').value = 'enter test';
	return true;
})());
$('#sh-schat-input').dispatchEvent(new window.KeyboardEvent('keydown', { key: 'Enter', bubbles: true, cancelable: true }));
await sleep(30);
check('Enter-to-send actually posted', reqs('send').some((r) => r.p.get('message') === 'enter test'));

window.close();
console.log('\n' + passed + ' passed, ' + failures.length + ' failed');
if (failures.length) { failures.forEach((f) => console.log('  - ' + f)); }
console.log(failures.length ? 'SUPPORT CHAT BEHAVIOUR: FAILED' : 'SUPPORT CHAT BEHAVIOUR: ALL CHECKS PASSED');
process.exit(failures.length ? 1 : 0);
