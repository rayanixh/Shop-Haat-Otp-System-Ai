<?php
/**
 * AI Customer Support — pure-logic tests (no database, no network).
 *
 * Covers the parts that decide safety and honesty without MySQL: language
 * detection (Bengali script / Banglish / English), order-reference and phone
 * extraction, product-query cleanup, the deterministic composer's factual
 * wording, the AI output guard (unverified amounts and action claims are
 * rejected), message shaping for the widget, and the static wiring (CSRF,
 * permissions, no AI-generation-log reuse, no inner scroll box).
 *
 *     php tests/support-unit.php
 */
declare(strict_types=1);

$_SERVER['SCRIPT_NAME'] = '/tests/support-unit.php';
$_SERVER['HTTP_HOST'] = 'localhost';
$_SERVER['REMOTE_ADDR'] = '127.0.0.1';
$_SERVER['REQUEST_METHOD'] = 'GET';

require_once dirname(__DIR__) . '/config/config.php';
require_once SH_ROOT . '/includes/support.php';

$passed = 0; $failed = 0; $failures = [];
function su_ok(bool $cond, string $msg): void
{
    global $passed, $failed, $failures;
    if ($cond) { $passed++; echo "  PASS  $msg\n"; return; }
    $failed++; $failures[] = $msg; echo "  FAIL  $msg\n";
}
function su_eq($exp, $act, string $msg): void
{
    su_ok($exp === $act, $msg . ' (expected ' . var_export($exp, true) . ', got ' . var_export($act, true) . ')');
}
$src = static fn(string $rel): string => (string)file_get_contents(SH_ROOT . '/' . $rel);

echo "Support unit tests (no DB)\n";

/* --- Language detection -------------------------------------------------- */
su_eq('bn', sh_support_detect_lang('এই জুতাটা কি পাওয়া যাবে?'), 'Bengali script detected as bn');
su_eq('bn', sh_support_detect_lang('আমার অর্ডার কোথায়?'), 'Bengali order question detected as bn');
su_eq('banglish', sh_support_detect_lang('Vai, ei shirt ta ki ache?'), 'Banglish availability detected');
su_eq('banglish', sh_support_detect_lang('amar order ta ekhono ashe nai'), 'Banglish order complaint detected');
su_eq('banglish', sh_support_detect_lang('Agertar blue color ta dekhaw'), 'Banglish follow-up detected');
su_eq('banglish', sh_support_detect_lang('dam koto?'), 'Banglish price question detected');
su_eq('en', sh_support_detect_lang('Do you have this shoe in stock?'), 'English detected');
su_eq('en', sh_support_detect_lang('Where is my order?'), 'English order question detected');
su_eq('en', sh_support_detect_lang('Hello, I need help with a return'), 'English greeting+request detected');

/* --- Extraction ------------------------------------------------------------ */
su_eq('01712345678', sh_support_extract_phone('amar number 01712-345678'), 'BD phone extracted with separators');
su_eq('+8801712345678', sh_support_extract_phone('call +8801712345678 please'), 'BD phone extracted with country code');
su_eq(null, sh_support_extract_phone('order 12345'), 'Short number is not a phone');
su_eq('SH26081501234', sh_support_extract_order_ref('order SH26081501234 kothay'), 'Full order number extracted');
su_eq('SH260815-01234', sh_support_extract_order_ref('Order: sh260815-01234'), 'Dashed order number extracted');
$opaqueOrderRef = 'AB' . str_repeat('A', 24);
su_eq($opaqueOrderRef, sh_support_extract_order_ref('Order ' . $opaqueOrderRef . ' status please'), 'Opaque random order reference extracted for any configured two-letter prefix');
su_ok(str_contains($src('includes/ai-support.php'), '[A-Z]{2}[A-F0-9]{24}'), 'AI support recognizes opaque random order references');
su_eq(null, sh_support_extract_order_ref('my order id 12345 status ki'), 'Internal numeric database ID is not accepted as a customer order reference');
su_ok(str_contains($src('includes/support.php'), "\$uid = function_exists('sh_user_id') ? sh_user_id() : 0;")
   && str_contains($src('includes/support.php'), 'AND customer_phone IN ({$phoneMarks}) LIMIT 1')
   && !str_contains($src('includes/support.php'), 'if (!$ok && $uid > 0'),
   'Support phone-pair verification is limited to anonymous chats; signed-in lookups require ownership');
su_ok(!str_contains($src('includes/support.php'), "WHERE id = ? LIMIT 1', [(int)$ref]"), 'Support lookup does not resolve internal numeric order IDs');
su_ok(str_contains($src('includes/support.php'), 'sh_order_tracking_rate_limited($ref')
   && str_contains($src('includes/support.php'), "require_once SH_ROOT . '/includes/order-tracking.php';"),
   'Anonymous support lookups share the public tracking rate limit');
$supportSrc = $src('includes/support.php');
$toolStart = strpos($supportSrc, 'function sh_support_tool_order(');
$toolEnd = strpos($supportSrc, 'function sh_support_tool_latest_own_order(', $toolStart ?: 0);
$toolBody = $toolStart !== false && $toolEnd !== false ? substr($supportSrc, $toolStart, $toolEnd - $toolStart) : '';
su_ok($toolBody !== ''
   && str_contains($toolBody, '$uid = function_exists(\'sh_user_id\') ? sh_user_id() : 0;')
   && strpos($toolBody, 'if ($uid <= 0 && ($phone === null') < strpos($toolBody, 'FROM orders WHERE order_number IN')
   && str_contains($toolBody, 'AND user_id = ? LIMIT 1')
   && str_contains($toolBody, 'AND customer_phone IN ({$phoneMarks}) LIMIT 1')
   && !str_contains($toolBody, 'SELECT * FROM orders')
   && !str_contains($toolBody, 'in_array((string)$row'),
   'Support uses session-owner/reference SQL for signed-in customers and reference-plus-phone SQL for anonymous visitors');
su_ok(str_contains($supportSrc, 'if ($phone !== null && $res[\'state\'] !== \'found\')')
   && str_contains($supportSrc, 'sh_support_rate_bump($bucket, 3600)'),
   'Failed anonymous support verification remains rate limited');
su_ok(str_contains($supportSrc, "defined('SH_CURRENT_SUPPORT_MODULE_LOADED')")
   && str_contains($src('includes/ai-support.php'), "defined('SH_LEGACY_SUPPORT_MODULE_LOADED')"),
   'Overlapping legacy/current support declarations are guarded against co-loading');
su_eq(null, sh_support_extract_order_ref('just browsing shoes'), 'No order ref in plain text');

/* --- Product query cleanup --------------------------------------------------- */
su_eq('nike shoe', sh_support_product_query('Nike shoe ache?'), 'Query keeps product words (Banglish)');
su_eq('nike shoe', sh_support_product_query('nike shoe er dam koto?'), 'Query strips price words');
su_eq('running shoes', sh_support_product_query('show me running shoes please'), 'Query strips English filler');

/* --- Composer (deterministic, factual) -------------------------------------- */
$cfg = sh_support_defaults();
$cfg['languages'] = ['bn', 'banglish', 'en'];
$base = ['intent' => 'fallback', 'lang' => 'en', 'query' => '', 'products' => [], 'product' => null,
         'order' => null, 'order_state' => 'none', 'policy' => '', 'faq' => null, 'size_asked' => '',
         'color_asked' => '', 'amounts' => [], 'facts_text' => '', 'force_deterministic' => false, 'context_updates' => []];

$r = $base; $r['intent'] = 'product'; $r['lang'] = 'banglish';
$r['product'] = ['id' => 7, 'name' => 'Trail Runner Shoe', 'url' => '/product.php?slug=trail', 'price' => 1250.0,
                 'price_fmt' => 'Tk 1,250', 'compare' => 1500.0, 'compare_fmt' => 'Tk 1,500', 'stock' => 3,
                 'availability' => 'low_stock', 'short' => '', 'spec' => ''];
$r['products'] = [$r['product']]; $r['size_asked'] = '42';
$out = sh_support_compose($r, $cfg);
su_ok(str_contains($out, 'Tk 1,250') && str_contains($out, '3 ti baki'), 'Banglish product reply carries verified price + low stock count');
su_ok(str_contains($out, '42') && str_contains($out, 'product page'), 'Size answer is honest: options on product page, product-level stock');

$r['product']['availability'] = 'out_of_stock'; $r['products'] = [$r['product']]; $r['size_asked'] = '';
$out = sh_support_compose($r, $cfg);
su_ok(str_contains($out, 'stock e nai'), 'Out-of-stock is stated plainly in Banglish');

$r2 = $base; $r2['intent'] = 'order'; $r2['order_state'] = 'need_phone'; $r2['lang'] = 'bn';
$out = sh_support_compose($r2, $cfg);
su_ok(str_contains($out, 'ফোন নম্বর'), 'Bengali need-phone reply asks for checkout phone (both-factor)');
$r2['order_state'] = 'not_found';
su_ok(sh_support_compose($r2, $cfg) !== '', 'Not-found order reply is generic (no enumeration hints)');

$r3 = $base; $r3['intent'] = 'order'; $r3['order_state'] = 'found';
$r3['order'] = ['order_number' => 'SH26081501234', 'status' => 'shipped', 'payment_status' => 'paid',
                'placed' => '2026-08-15 10:00:00', 'total' => 2250.0, 'total_fmt' => 'Tk 2,250',
                'delivery_fee' => 60.0, 'items' => ['Trail Runner Shoe ×1'], 'item_count' => 1,
                'shipment' => ['courier' => 'FastCourier', 'tracking' => 'FC9988', 'status' => 'in_transit', 'cod' => 0.0, 'delivered_at' => '']];
$out = sh_support_compose($r3, $cfg);
su_ok(str_contains($out, 'SH26081501234') && str_contains($out, 'FC9988') && str_contains($out, 'Shipped'), 'Order reply uses real status + tracking from facts');

/* --- AI guard ----------------------------------------------------------------- */
$gr = $base; $gr['amounts'] = [1250.0, 1500.0];
su_ok(sh_support_ai_guard('এটির দাম ৳1,250 এবং স্টকে আছে।', $gr), 'Guard allows the verified price (Bengali)');
su_ok(sh_support_ai_guard('The price is BDT 1250 only.', $gr), 'Guard allows verified price without separators');
su_ok(!sh_support_ai_guard('Special offer: only ৳999 today!', $gr), 'Guard rejects an invented lower price');
su_ok(!sh_support_ai_guard('দাম মাত্র ৯৯৯ টাকা — sorry, 999 taka!', $gr), 'Guard rejects invented taka amount');
su_ok(!sh_support_ai_guard('Done — I have cancelled your order.', $gr), 'Guard rejects first-person cancel claim');
su_ok(!sh_support_ai_guard('আমি বাতিল করে দিয়েছি।', $gr), 'Guard rejects Bengali cancel claim');
su_ok(!sh_support_ai_guard('refund kore dilam', $gr), 'Guard rejects Banglish refund claim');
$gr2 = $base; $gr2['amounts'] = [];
su_ok(sh_support_ai_guard('Delivery usually takes 2-3 days inside Dhaka.', $gr2), 'Guard allows amount-free text');
su_ok(!sh_support_ai_guard('Delivery charge is ৳60.', $gr2), 'Guard rejects any amount when none are verified');

/* --- Message shaping ------------------------------------------------------------ */
$pub = sh_support_message_public(['id' => 5, 'sender' => 'system', 'body' => 'Hi', 'created_at' => '2026-01-01 10:00:00',
    'facts_json' => json_encode(['kind' => 'assistant', 'source' => 'deterministic'])]);
su_eq('assistant', $pub['kind'], 'Deterministic assistant message renders as assistant bubble');
su_eq(false, $pub['ai'], 'Deterministic message is NOT flagged as AI');
$pub = sh_support_message_public(['id' => 6, 'sender' => 'ai', 'body' => 'Hi', 'created_at' => 'x', 'facts_json' => null]);
su_eq(true, $pub['ai'], 'Model-generated message IS flagged as AI');
$pub = sh_support_message_public(['id' => 7, 'sender' => 'admin', 'body' => 'Hi', 'created_at' => 'x', 'facts_json' => null]);
su_eq('agent', $pub['kind'], 'Admin message renders as agent');
su_ok(!array_key_exists('admin_id', $pub) && !array_key_exists('facts_json', $pub), 'Public shape leaks no internal fields');

/* --- Static wiring ---------------------------------------------------------------- */
su_ok(str_contains($src('api/support.php'), 'sh_csrf_require()'), 'Support API enforces CSRF');
// The active AI-support API builds a server-side owner context (logged-in user
// id + guest token) and every conversation lookup applies that owner clause.
su_ok(str_contains($src('api/support.php'), 'sh_support_owner_context(')
   && str_contains($src('includes/ai-support.php'), 'function sh_support_owner_clause(')
   && str_contains($src('includes/ai-support.php'), 'function sh_support_conversation_for_owner('),
   'Support API checks conversation ownership');
su_ok(!str_contains($src('includes/support.php'), 'sh_ai_dispatch('), 'Support never uses sh_ai_dispatch (would log full conversations)');
su_ok(str_contains($src('includes/support.php'), 'sh_support_ai_guard('), 'AI replies pass the factual guard');
su_ok(str_contains($src('includes/support.php'), 'FOR UPDATE'), 'Pipeline uses row locks around state changes');
su_ok(str_contains($src('includes/footer.php'), 'support-widget.php'), 'Widget is mounted in the storefront footer');
$permsSrc = $src('includes/admin-perms.php');
su_ok(str_contains($permsSrc, "'support.view'") && str_contains($permsSrc, "'support.reply'") && str_contains($permsSrc, "'support.manage'"), 'All support permissions are registered in the permission catalogue');
$layoutSrc = $src('admin/_layout.php');
su_ok(str_contains($layoutSrc, '$badgeSupport = 0;')
   && str_contains($layoutSrc, 'unread_for_admin')
   && str_contains($layoutSrc, "sh_admin_can('support.view'")
   && str_contains($layoutSrc, "'support.view'") && str_contains($layoutSrc, "'support.manage'"),
   'Admin sidebar has a guarded support unread counter and permission-gated links');
su_ok(str_contains($src('ai/ProviderManager.php'), "'support_chat'"), 'support_chat AI task registered');
foreach (['ai/providers/OpenAICompatibleProvider.php', 'ai/providers/GeminiProvider.php', 'ai/providers/AnthropicProvider.php'] as $pf) {
    su_ok(str_contains($src($pf), "\$options['timeout']"), "Caller timeout honored in $pf");
}
$schema = $src('install/schema.php');
su_ok(str_contains($schema, 'UNIQUE KEY uq_supmsg_client'), 'Client message id is unique (idempotent sends)');
su_ok(substr_count($schema, 'CREATE TABLE IF NOT EXISTS support_') === 6, 'Six additive support tables declared');
$js = $src('assets/js/support-chat.js');
su_ok(str_contains($js, 'textContent') && !str_contains($js, 'innerHTML'), 'Widget renders message text via textContent only (no HTML injection)');
// The floating widget is viewport-fixed. Its message log and both fixed-height
// composer textareas are the only support rules allowed to own an internal
// scroll region; long drafts scroll inside inputs instead of resizing the UI.
$css = $src('assets/css/app.css');
$supportCss = $src('assets/css/support.css');
$supportScrollRules = static function (string $stylesheet): array {
    preg_match_all('/\.(sh-schat[a-z0-9_-]*|sh-support-chat[a-z0-9_-]*)[^{]*\{([^}]*)\}/s', $stylesheet, $rules, PREG_SET_ORDER);
    $offenders = [];
    foreach ($rules as $rule) {
        if (preg_match('/overflow(?:-x|-y)?\s*:\s*(?:auto|scroll)/', $rule[2]) === 1) { $offenders[] = $rule[1]; }
    }
    return $offenders;
};
$widgetScroll = $supportScrollRules($css);
su_ok($widgetScroll === ['sh-schat-messages', 'sh-schat-input']
   && $supportScrollRules($supportCss) === ['sh-support-chat__compose']
   && preg_match('/overflow(?:-x|-y)?\s*:\s*(?:auto|scroll)/', $supportCss) === 1,
   'Only the fixed widget message log and both composer textareas scroll internally; no other support CSS creates a scroll box');
su_ok(str_contains($css, '.sh-schat-sheet {') && str_contains($css, 'position: fixed; right: 16px; left: auto; top: auto;')
   && str_contains($css, 'bottom: calc(var(--sh-schat-bottom) + env(safe-area-inset-bottom, 0px))')
   && str_contains($css, 'overscroll-behavior: contain;')
   && str_contains($src('assets/js/support-chat.js'), 'syncViewport()')
   && !str_contains($src('assets/js/support-chat.js'), 'window.scrollY'),
   'Widget panel is fixed/bottom-anchored with safe-area support and no document-scroll pinning');
// The old per-conversation page is now a permission-gated redirect into the
// guarded inbox; both endpoints require support.reply (directly or via manage).
su_ok(str_contains($src('admin/support-conversation.php'), "sh_require_perm('support.view', 'support.reply', 'support.manage')")
   && str_contains($src('admin/support.php'), "sh_admin_can('support.reply', 'support.manage')"),
   'Admin actions require support.reply');
// A real selected-model text test replaces the old assumed-working probe.
su_ok(str_contains($src('admin/support-settings.php'), 'sh_support_provider_test(')
   && str_contains($src('includes/ai-support.php'), 'function sh_support_provider_test(')
   && str_contains($src('admin/support-settings.php'), 'Not tested for this exact configuration'),
   'Settings page has a real AI probe (never assumed working)');

echo "\nPassed: $passed · Failed: $failed\n";
if ($failed > 0) { foreach ($failures as $f) { echo "  - $f\n"; } exit(1); }
exit(0);
