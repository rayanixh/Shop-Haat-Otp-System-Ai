<?php
/**
 * ShopHaat installer. Runs before any database exists, so it must be
 * completely self-contained and never fatal.
 */
declare(strict_types=1);

define('SH_ROOT_INSTALL', dirname(__DIR__));
require_once SH_ROOT_INSTALL . '/config/config.php';
require_once __DIR__ . '/schema.php';
require_once __DIR__ . '/demo-data.php';

sh_session_start();

/*
 * Installer access rule
 * ---------------------
 * The installer is only reachable when the store genuinely needs setting up or
 * repairing. If the database is present and healthy the visitor is sent straight
 * back to the storefront -- including when they hand-type ?step=repair.
 */
$shState = sh_db_state();
if ($shState['status'] === 'ok' && sh_is_locked()) {
    sh_redirect('index.php');
}

// ---------------------------------------------------------------------------
// Installer access decision (see includes/install-guard.php for the rationale).
//
// A store that was installed before resolves to "repair" mode. In that mode the
// installer will only re-create missing tables over the SAVED connection: it
// ignores every database credential in the request, never modifies an existing
// administrator account, and never rewrites config/database.php. Full setup
// (or an administrator reset) additionally requires the owner's unlock token.
// ---------------------------------------------------------------------------
require_once SH_ROOT_INSTALL . '/includes/install-guard.php';

$shUnlockGiven = (string)($_POST['install_unlock'] ?? '');
$shUnlockOk = $shUnlockGiven !== '' && sh_install_unlock_matches($shUnlockGiven);
$shAccess = sh_install_access(
    sh_is_locked(),
    sh_db_config() !== null,
    $shUnlockOk,
    sh_install_unlock_configured()
);
// Unlock attempts are rate limited per IP so the token cannot be brute forced
// from the open internet. The limiter fails CLOSED here: if the counter store is
// unavailable (full disk, read-only logs/) we refuse the *wrong* token instead of
// letting an attacker remove the throttle by breaking the store first. A correct
// token never consults the limiter, so the owner can still get in and repair.
$shUnlockThrottled = !$shUnlockOk && $shUnlockGiven !== ''
    && !sh_file_rate_limit('install-unlock', sh_client_ip(), 5, 900, '', true);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    sh_log_line('install', 'Installer accessed: mode=' . $shAccess['mode']
        . ' state=' . (string)$shState['status']
        . ' unlock_supplied=' . ($shUnlockGiven !== '' ? 'yes' : 'no'));
}

$errors = [];
$notice = '';
$done = false;

$form = [
    'db_host' => 'localhost', 'db_name' => '', 'db_user' => '', 'db_pass' => '',
    'site_name' => 'ShopHaat', 'admin_email' => '', 'admin_password' => '',
    'admin_password2' => '', 'demo_data' => '0',
];
// Credentials are taken exactly as typed: trimming a password silently changes
// what the administrator chose, and a database password may legitimately begin
// or end with a space.
$verbatim = ['db_pass', 'admin_password', 'admin_password2'];
foreach ($form as $k => $v) {
    if (!isset($_POST[$k]) || !is_string($_POST[$k])) { continue; }
    $form[$k] = in_array($k, $verbatim, true) ? (string)$_POST[$k] : trim((string)$_POST[$k]);
}
// One radio control, normalised to exactly '0' or '1' so the seeding decision
// can never be flipped by an unexpected value (including a crafted duplicate
// field) and the rendered control always reflects what the backend will do.
$form['demo_data'] = ($form['demo_data'] === '1') ? '1' : '0';

// On a repair, pre-fill the saved connection so the operator mostly confirms what is there.
// The stored password is deliberately NOT pre-filled into the HTML.
$savedCfg = sh_db_config();
if ($savedCfg !== null && $_SERVER['REQUEST_METHOD'] !== 'POST') {
    $form['db_host'] = (string)$savedCfg['host'];
    $form['db_name'] = (string)$savedCfg['name'];
    $form['db_user'] = (string)$savedCfg['user'];
}

// ---------------------------------------------------------------------------
// Server requirement checks
// ---------------------------------------------------------------------------
// Required checks block the install. Optional extensions are reported with the
// behaviour used instead — the application ships fallbacks for every one of
// them (includes/compat.php), so a host without mbstring, DOM, cURL or GD still
// installs and runs, it just loses the related convenience feature.
$requirements = [
    ['label' => 'PHP 8.1 or newer',     'ok' => version_compare(PHP_VERSION, '8.1.0', '>='), 'value' => PHP_VERSION],
    ['label' => 'PDO extension',        'ok' => extension_loaded('pdo'), 'value' => extension_loaded('pdo') ? 'Enabled' : 'Missing'],
    ['label' => 'pdo_mysql driver',     'ok' => extension_loaded('pdo_mysql'), 'value' => extension_loaded('pdo_mysql') ? 'Enabled' : 'Missing'],
    ['label' => 'JSON extension',       'ok' => extension_loaded('json'), 'value' => extension_loaded('json') ? 'Enabled' : 'Missing'],
    ['label' => '/config writable',     'ok' => is_writable(SH_CONFIG_DIR), 'value' => is_writable(SH_CONFIG_DIR) ? 'Writable' : 'Not writable'],
    ['label' => '/uploads writable',    'ok' => is_writable(SH_UPLOAD_DIR), 'value' => is_writable(SH_UPLOAD_DIR) ? 'Writable' : 'Not writable'],
    ['label' => '/logs writable',       'ok' => is_writable(SH_LOG_DIR), 'value' => is_writable(SH_LOG_DIR) ? 'Writable' : 'Not writable'],
];
$reqOk = true;
foreach ($requirements as $r) { if (!$r['ok']) { $reqOk = false; } }

// Optional extensions: never block installation, always reported.
$optionalRequirements = [];
foreach (sh_extension_requirements() as $ext) {
    if ($ext['required']) { continue; }
    $optionalRequirements[] = [
        'label'    => $ext['label'] . ' — ' . $ext['purpose'],
        'ok'       => $ext['ok'],
        'value'    => $ext['ok'] ? 'Enabled' : ($ext['fallback'] !== '' ? 'Fallback: ' . $ext['fallback'] : 'Not enabled'),
    ];
}

// ---------------------------------------------------------------------------
// Handle submission
// ---------------------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!sh_csrf_valid()) {
        $errors[] = 'Your session expired. Please submit the form again.';
    } elseif (!$reqOk) {
        $errors[] = 'Please resolve the server requirement issues listed above before installing.';
    } elseif (($_POST['form'] ?? '') === 'unlock') {
        // A deliberate unlock attempt: give the owner explicit feedback instead
        // of silently running a repair.
        if ($shUnlockThrottled) {
            $errors[] = 'Too many unlock attempts from this address. Please wait 15 minutes and try again.';
        } elseif ($shUnlockOk) {
            $notice = 'Installer unlocked. This applies to the submission you send next, so keep the page open and '
                . 'complete the form below.';
        } else {
            $errors[] = 'That unlock text did not match the file on the server. '
                . 'Check the file content — the whole line is compared, including case.';
        }
    } elseif ($shAccess['mode'] === 'repair') {
        // ------------------------------------------------------------------
        // Repair only. Nothing from the request body is used to reach the
        // database, so an anonymous visitor cannot redirect this store at a
        // database of their choosing or add themselves as an administrator.
        // ------------------------------------------------------------------
        if ($shAccess['can_repair'] === false) {
            $errors[] = 'The installation lock file is present but config/database.php is missing, so there is '
                . 'no saved connection to repair. Restore config/database.php from your backup, or unlock the '
                . 'installer as the store owner to configure a new database.';
        } else {
            $saved = sh_db_config();
            try {
                // Step 1: reach the server with the SAVED credentials.
                $pdo = sh_db_connect($saved['host'], null, $saved['user'], $saved['pass'], (int)$saved['port'], $saved['charset']);
                // Step 2: the database named in the saved configuration may
                // itself be gone (dropped or renamed by the host). Recreate only
                // that name.
                $exists = $pdo->prepare('SELECT COUNT(*) FROM information_schema.schemata WHERE schema_name = ?');
                $exists->execute([$saved['name']]);
                if ((int)$exists->fetchColumn() === 0) {
                    $pdo->exec('CREATE DATABASE `' . str_replace('`', '', (string)$saved['name'])
                        . '` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
                }
                $pdo = sh_db_connect($saved['host'], $saved['name'], $saved['user'], $saved['pass'], (int)$saved['port'], $saved['charset']);

                // Step 3: re-create anything missing. CREATE TABLE IF NOT EXISTS
                // never drops or alters a table that already holds data.
                foreach (sh_schema_sql() as $ddl) { $pdo->exec($ddl); }

                $missing = [];
                $chk = $pdo->prepare('SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = ? AND table_name = ?');
                foreach (sh_schema_tables() as $t) {
                    $chk->execute([$saved['name'], $t]);
                    if ((int)$chk->fetchColumn() === 0) { $missing[] = $t; }
                }
                if ($missing) {
                    throw new RuntimeException('Tables not created: ' . implode(', ', $missing));
                }

                // Step 4: existing administrators are never touched. Only a
                // store that has no administrator at all may create its first
                // one — that state can only be produced through real database
                // access, which an anonymous visitor does not have.
                $adminCount = (int)$pdo->query('SELECT COUNT(*) FROM admins')->fetchColumn();
                if ($adminCount > 0) {
                    $done = true;
                    $notice = 'Database repaired against ' . $saved['name']
                        . '. The existing administrator account was left untouched — sign in with your usual credentials.';
                } else {
                    // A first administrator for an empty admins table. The
                    // submitted values are validated exactly as on a fresh
                    // install and inserted once, never as an upsert.
                    $v = new ShValidator($_POST);
                    $v->required('admin_email', 'Admin email')->email('admin_email', 'Admin email')
                      ->required('admin_password', 'Admin password')->password('admin_password', 'admin')
                      ->matchesRaw('admin_password2', 'admin_password', 'Password confirmation');
                    if ($v->fails()) {
                        $errors = array_merge($errors, array_values($v->errors()));
                        $errors[] = 'The database was repaired, but no administrator exists yet. '
                            . 'Enter the email address and password for the first administrator account.';
                    } else {
                        $ins = $pdo->prepare('INSERT INTO admins (name, email, password_hash, role, status) VALUES (?,?,?,?,?)');
                        $ins->execute([
                            'Store Administrator',
                            trim((string)$_POST['admin_email']),
                            password_hash((string)$_POST['admin_password'], PASSWORD_DEFAULT),
                            'superadmin',
                            'active',
                        ]);
                        sh_log_line('install', 'Repair created the first administrator account.');
                        $done = true;
                        $notice = 'Database repaired against ' . $saved['name'] . ' and the store administrator was created.';
                    }
                }

                if ($done) {
                    file_put_contents(SH_LOCK_FILE, json_encode([
                        'installed_at' => date('c'),
                        'version'      => '1.0.0',
                        'php'          => PHP_VERSION,
                        'repair'       => true,
                    ], JSON_PRETTY_PRINT));
                }
            } catch (Throwable $e) {
                sh_log_exception($e, 'install-repair');
                $errors[] = 'The repair could not reach the saved database. Your configuration was not changed. '
                    . 'Check that the MySQL server is running and that the database user in config/database.php '
                    . 'still exists.';
            }
        }
    } else {
        $v = new ShValidator($_POST);
        $v->required('db_host', 'Database host')
          ->required('db_name', 'Database name')
          ->required('db_user', 'Database username')
          ->required('site_name', 'Website name')->maxLen('site_name', 100, 'Website name')
          ->required('admin_email', 'Admin email')->email('admin_email', 'Admin email')
          ->required('admin_password', 'Admin password')->password('admin_password', 'admin')
          ->matchesRaw('admin_password2', 'admin_password', 'Password confirmation');
        if ($v->fails()) { $errors = array_merge($errors, array_values($v->errors())); }

        $logoFile = null;
        if (!$errors && isset($_FILES['site_logo']) && ($_FILES['site_logo']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE) {
            $up = sh_upload_image($_FILES['site_logo'], 'logos', 0, 2000);
            if (!$up['ok']) { $errors[] = 'Website logo: ' . $up['error']; }
            else { $logoFile = $up['file']; }
        }

        // Step 2: connect
        $pdo = null;
        if (!$errors) {
            try {
                $pdo = sh_db_connect($form['db_host'], null, $form['db_user'], $form['db_pass']);
            } catch (PDOException $e) {
                sh_log_line('install', 'Connection failed: ' . $e->getMessage());
                $errors[] = 'Could not connect to the database server. Check the host, username and password.';
            }
        }
        // Step 3: detect engine + select/create database
        if (!$errors && $pdo) {
            try {
                $version = (string)$pdo->query('SELECT VERSION()')->fetchColumn();
                $isMaria = stripos($version, 'mariadb') !== false;
                if (!$isMaria && version_compare(preg_replace('/[^0-9.].*$/', '', $version), '5.7.0', '<')) {
                    $errors[] = 'MySQL 5.7+ or MariaDB 10.2+ is required. Detected: ' . $version;
                }
                if (!$errors) {
                    $exists = $pdo->prepare('SELECT COUNT(*) FROM information_schema.schemata WHERE schema_name = ?');
                    $exists->execute([$form['db_name']]);
                    if ((int)$exists->fetchColumn() === 0) {
                        try {
                            $pdo->exec('CREATE DATABASE `' . str_replace('`', '', $form['db_name']) . '` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
                        } catch (PDOException $e) {
                            $errors[] = 'The database "' . $form['db_name'] . '" does not exist and could not be created. Please create it in cPanel first.';
                        }
                    }
                }
                if (!$errors) {
                    $pdo = sh_db_connect($form['db_host'], $form['db_name'], $form['db_user'], $form['db_pass']);
                }
            } catch (PDOException $e) {
                sh_log_line('install', 'Database selection failed: ' . $e->getMessage());
                $errors[] = 'Connected to the server but could not open the database "' . e($form['db_name']) . '".';
            }
        }
        // Step 4-7: schema, admin, settings, verification
        if (!$errors && $pdo) {
            try {
                $pdo->exec('SET FOREIGN_KEY_CHECKS = 1');
                foreach (sh_schema_sql() as $ddl) { $pdo->exec($ddl); }

                // Verify every expected table now exists
                $missing = [];
                $chk = $pdo->prepare('SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = ? AND table_name = ?');
                foreach (sh_schema_tables() as $t) {
                    $chk->execute([$form['db_name'], $t]);
                    if ((int)$chk->fetchColumn() === 0) { $missing[] = $t; }
                }
                if ($missing) {
                    throw new RuntimeException('Tables not created: ' . implode(', ', $missing));
                }

                $siteUrl = rtrim(sh_site_url(), '/');

                // One shared call creates the administrator and applies the Demo
                // Data choice in a single transaction (see
                // sh_install_create_store()). It refuses to run when an
                // administrator already exists, so a repeated install can never
                // silently reset somebody's password. Recovery is the owner
                // unlock path, not a re-run of this form.
                //
                // $form['demo_data'] is normalised to exactly '0' or '1' during
                // validation, so a crafted "demo_data=0,1" or an empty value cannot
                // slip past this compare. The backend makes the decision from the
                // validated value, never from the state of a control in the browser.
                $ownerRecovery = $shAccess['mode'] === 'unlocked';
                $shSeedReport = sh_install_create_store($pdo, $form, $logoFile ?? '', $siteUrl, $ownerRecovery);
                sh_log_line('install', ($ownerRecovery ? 'Owner-authorized install/recovery: ' : 'Seeding: ')
                    . json_encode($shSeedReport));

                // Write config
                $cfgContent = "<?php
// Note: the setup wizard deliberately does NOT render the Page Transition. It
// runs before the store has any settings to read (the transition is stored in
// the settings table) and it must stay usable with no JavaScript at all.
?>
<?php\n// Generated by the ShopHaat installer on " . date('Y-m-d H:i:s') . ".\n"
                    . "// Do not share this file. Keep it outside version control.\nreturn "
                    . var_export([
                        'host'    => $form['db_host'],
                        'name'    => $form['db_name'],
                        'user'    => $form['db_user'],
                        'pass'    => $form['db_pass'],
                        'port'    => 3306,
                        'charset' => 'utf8mb4',
                    ], true) . ";\n";
                if (file_put_contents(SH_DB_CONFIG_FILE, $cfgContent) === false) {
                    throw new RuntimeException('Unable to write config/database.php. Set the /config folder to 755 and retry.');
                }
                if (!chmod(SH_DB_CONFIG_FILE, 0640)) {
                    sh_log_line('install', 'Could not tighten permissions on the database config file.');
                }

                // Make sure every upload subdirectory exists and is protected.
                foreach (['products', 'logos', 'payments', 'promo', 'categories'] as $sub) {
                    $d = SH_UPLOAD_DIR . '/' . $sub;
                    if (!is_dir($d) && !mkdir($d, 0755, true) && !is_dir($d)) {
                        sh_log_line('install', 'Could not create upload directory: ' . $d);
                    }
                }
                $uploadGuard = SH_UPLOAD_DIR . '/.htaccess';
                if (!is_file($uploadGuard)) {
                    file_put_contents($uploadGuard,
                        "# Uploaded files must never be executed as code.\n"
                        . "<FilesMatch \"\\.(php|phtml|php[0-9]|pl|py|cgi|sh|htaccess)$\">\n"
                        . "  Require all denied\n</FilesMatch>\n"
                        . "Options -ExecCGI -Indexes\nRemoveHandler .php .phtml .phar\n"
                        // php_flag is mod_php-only; unguarded it 500s the whole
                        // folder on FastCGI/PHP-FPM hosts and hides every image.
                        . "<IfModule mod_php.c>\n  php_flag engine off\n</IfModule>\n"
                        . "<IfModule mod_php7.c>\n  php_flag engine off\n</IfModule>\n");
                }

                // Lock
                file_put_contents(SH_LOCK_FILE, json_encode([
                    'installed_at' => date('c'),
                    'version'      => '1.0.0',
                    'php'          => PHP_VERSION,
                ], JSON_PRETTY_PRINT));

                $done = true;
                $notice = !empty($shSeedReport['recovered'])
                    ? 'The existing administrator password was reset through the owner unlock.'
                    : 'Installation completed successfully.';
            } catch (Throwable $e) {
                sh_log_exception($e, 'install');
                $errors[] = 'Installation failed. The details were written to the server log.';
            }
        }
    }
}

$token = sh_csrf_token();
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title>Install ShopHaat</title>
<style>
:root{--brand:#e8501b;--ink:#1f2430;--muted:#697084;--line:#e3e6ec;--bg:#f4f5f7;--ok:#1a7f4b;--bad:#c62828;color-scheme:light}
*,*::before,*::after{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--ink);font:15px/1.55 system-ui,-apple-system,"Segoe UI",Roboto,Arial,sans-serif;padding:24px 14px}
.wrap{max-width:820px;margin:0 auto}
.head{text-align:center;margin-bottom:22px}
.head h1{margin:0 0 6px;font-size:24px}
.head p{margin:0;color:var(--muted);font-size:14px}
.mark{display:inline-flex;align-items:center;gap:9px;font-weight:800;font-size:20px;letter-spacing:-.3px;margin-bottom:10px}
.mark span{display:inline-grid;place-items:center;width:34px;height:34px;border-radius:8px;background:var(--brand);color:#fff;font-size:16px}
.card{background:#fff;border:1px solid var(--line);border-radius:10px;padding:22px;margin-bottom:18px}
.card h2{margin:0 0 14px;font-size:15px;text-transform:uppercase;letter-spacing:.5px;color:var(--muted)}
.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}
@media(max-width:640px){.grid{grid-template-columns:1fr}}
label{display:block;font-size:13px;font-weight:600;margin-bottom:5px}
.f-in{width:100%;padding:9px 11px;border:1px solid var(--line);border-radius:6px;font-size:14px;font-family:inherit;background:#fff;color:var(--ink)}
.f-in:focus{outline:2px solid rgba(232,80,27,.25);border-color:var(--brand)}
.hint{font-size:12px;color:var(--muted);margin-top:4px}
.btn{background:var(--brand);color:#fff;border:0;padding:12px 26px;border-radius:6px;font-size:15px;font-weight:700;cursor:pointer;font-family:inherit;width:100%}
.btn:hover{background:#cf4415}
.btn[disabled]{background:#b9bec9;cursor:not-allowed}
.req{list-style:none;margin:0;padding:0}
.req li{display:grid;grid-template-columns:minmax(0,1fr) fit-content(50%);column-gap:14px;align-items:start;padding:6px 0;border-bottom:1px dashed var(--line);font-size:13.5px}
.req li:last-child{border-bottom:0}
.ok{color:var(--ok);font-weight:600}.bad{color:var(--bad);font-weight:600}.warn{color:#a15c07;font-weight:600}
.alert{border-radius:7px;padding:12px 14px;font-size:13.5px;margin-bottom:16px;border:1px solid}
.alert--bad{background:#fdecea;border-color:#f5c2bd;color:#8c1d13}
.alert--ok{background:#e8f6ee;border-color:#bfe3cd;color:#14603a}
.alert ul{margin:6px 0 0;padding-left:18px}
.done{text-align:center}
.done h2{font-size:20px;color:var(--ok);text-transform:none;letter-spacing:0;margin-bottom:8px}
.actions{display:flex;gap:10px;justify-content:center;flex-wrap:wrap;margin-top:18px}
.actions a{display:inline-block;padding:11px 22px;border-radius:6px;text-decoration:none;font-weight:600;font-size:14px}
.a1{background:var(--brand);color:#fff}.a2{background:#fff;border:1px solid var(--line);color:var(--ink)}
.check{display:flex;gap:9px;align-items:flex-start;font-size:13.5px}
.check input{margin-top:3px}
.pw-live{margin:6px 0 0;font-size:12.5px;font-weight:600}
.pw-live--ok{color:#1a7f4b}
.pw-live--bad{color:#c62828}
.hint code{background:#f1f2f5;padding:1px 5px;border-radius:4px;font-size:12px}
/* Overflow safety only: no layout, spacing or colour changes. A requirement
   name, a detected value or a path can be long, so each one wraps inside its
   own box instead of widening the card or the page. Nothing is clipped or
   hidden — the row simply grows taller, and the status keeps its own space. */
.wrap{width:100%;min-width:0}
.card{min-width:0}
.req li>span{min-width:0;max-width:100%;overflow-wrap:anywhere;word-break:break-word}
.req li>span:last-child{justify-self:end;text-align:right;white-space:normal}
.card h2,.head h1,.head p,.card p,.alert,.hint,label,.check,.done{overflow-wrap:anywhere}
code{overflow-wrap:anywhere;word-break:break-word}
.btn{max-width:100%;white-space:normal}
.f-in{max-width:100%;min-width:0}
.grid>div{min-width:0}
.actions a{max-width:100%;text-align:center}
.alert li{overflow-wrap:anywhere}
</style>
</head>
<body>
<div class="wrap">
  <div class="head">
    <div class="mark"><span>SH</span> ShopHaat</div>
    <h1><?= $done ? 'Installation complete' : ($shAccess['mode'] === 'repair' ? 'Repair this store' : 'Install your store') ?></h1>
    <p><?php
        if ($done) { echo 'Your marketplace is ready to use.'; }
        elseif ($shAccess['mode'] === 'repair') { echo 'Re-create the missing database tables over the saved connection.'; }
        else { echo 'Enter your cPanel MySQL details and create the admin account.'; }
    ?></p>
  </div>

<?php if ($done): ?>
  <div class="card done">
    <p><?= e($notice) ?></p>
    <p>The installer is locked and will not run again.</p>
    <div class="alert alert--bad" style="text-align:left">
      <strong>Delete the <code>/install</code> folder</strong> from your hosting account now.
    </div>
    <div class="actions">
      <a class="a1" href="<?= e(sh_url('index.php')) ?>">Open the website</a>
      <a class="a2" href="<?= e(sh_url('admin/login.php')) ?>">Go to admin panel</a>
    </div>
  </div>
<?php else: ?>
  <?php if ($errors): ?>
    <div class="alert alert--bad"><strong>Installation could not continue:</strong>
      <ul><?php foreach ($errors as $er): ?><li><?= e($er) ?></li><?php endforeach; ?></ul>
    </div>
  <?php endif; ?>
  <div class="card">
    <h2>Server requirements</h2>
    <ul class="req">
      <?php foreach ($requirements as $r): ?>
        <li><span><?= e($r['label']) ?></span><span class="<?= $r['ok'] ? 'ok' : 'bad' ?>"><?= e($r['value']) ?></span></li>
      <?php endforeach; ?>
    </ul>
    <ul class="req">
      <?php foreach ($optionalRequirements as $r): ?>
        <li><span><?= e($r['label']) ?></span><span class="<?= $r['ok'] ? 'ok' : 'warn' ?>"><?= e($r['value']) ?></span></li>
      <?php endforeach; ?>
    </ul>
  </div>

<?php if ($shAccess['mode'] === 'repair'): ?>
  <div class="card">
    <h2>Restricted: this store is already installed</h2>
    <p style="margin:0 0 14px;font-size:13.5px">
      Repair re-creates missing tables over the saved connection in <code>config/database.php</code>.
      Existing tables, orders and administrator accounts are left as they are, and no credentials are accepted here.
    </p>
    <?php if ($shAccess['can_repair']): ?>
      <form method="post" novalidate>
        <input type="hidden" name="csrf_token" value="<?= e($token) ?>">
        <input type="hidden" name="form" value="repair">
        <div class="grid" style="margin-bottom:14px">
          <div>
            <label for="admin_email">First administrator email (only used if no administrator exists)</label>
            <input class="f-in" id="admin_email" name="admin_email" type="email" value="<?= e($form['admin_email']) ?>">
          </div>
          <div>
            <label for="admin_password">Password for that account</label>
            <input class="f-in" id="admin_password" name="admin_password" type="password"
                   minlength="<?= (int)sh_password_min_length('admin') ?>" maxlength="200"
                   autocomplete="new-password">
          </div>
          <div>
            <label for="admin_password2">Confirm password</label>
            <input class="f-in" id="admin_password2" name="admin_password2" type="password" autocomplete="new-password">
          </div>
        </div>
        <p class="hint">At least <?= (int)sh_password_min_length('admin') ?> characters. Only used if no administrator exists.</p>
        <button class="btn" type="submit" <?= $reqOk ? '' : 'disabled' ?>>Repair database tables</button>
      </form>
    <?php else: ?>
      <div class="alert alert--bad" style="margin-bottom:0">
        <strong>config/database.php is missing</strong>, so there is no saved connection to repair.
        Restore that file from your backup and reload this page.
      </div>
    <?php endif; ?>
  </div>

  <div class="card">
    <h2>Store owner: unlock full setup</h2>
    <p style="margin:0 0 10px;font-size:13.5px">
      Re-installing or resetting the administrator password requires proof that you control the server files.
    </p>
    <ol style="margin:0 0 14px;padding-left:20px;font-size:13px;color:#3a4152">
      <?php foreach (sh_install_unlock_instructions() as $line): ?><li style="margin-bottom:6px"><?= $line ?></li><?php endforeach; ?>
    </ol>
    <?php if (!$shAccess['unlock_configured']): ?>
      <div class="alert alert--bad">
        No unlock file was found. Create it as described above, then reload this page.
      </div>
    <?php endif; ?>
    <form method="post" novalidate>
      <input type="hidden" name="csrf_token" value="<?= e($token) ?>">
      <input type="hidden" name="form" value="unlock">
      <label for="install_unlock">Unlock text (contents of the file)</label>
      <input class="f-in" id="install_unlock" name="install_unlock" autocomplete="off" spellcheck="false"
             placeholder="Paste the exact line you saved">
      <button class="btn" type="submit" style="margin-top:12px">Unlock the installer</button>
    </form>
  </div>
<?php else: ?>
  <?php if ($shAccess['mode'] === 'unlocked'): ?>
    <div class="alert alert--ok">
      <strong>Owner unlock accepted.</strong> Changes made here affect an installed store. The unlock text is
      required again for the next submission, so finish in this same page.
    </div>
  <?php endif; ?>
  <form method="post" enctype="multipart/form-data" novalidate>
    <input type="hidden" name="csrf_token" value="<?= e($token) ?>">
    <?php if ($shAccess['mode'] === 'unlocked'): ?>
      <input type="hidden" name="install_unlock" value="<?= e($shUnlockGiven) ?>">
    <?php endif; ?>
    <div class="card">
      <h2>Database connection</h2>
      <div class="grid">
        <div>
          <label for="db_host">Database host</label>
          <input class="f-in" id="db_host" name="db_host" value="<?= e($form['db_host']) ?>" required>
          <p class="hint">Usually <code>localhost</code>.</p>
        </div>
        <div>
          <label for="db_name">Database name</label>
          <input class="f-in" id="db_name" name="db_name" value="<?= e($form['db_name']) ?>" required>
        </div>
        <div>
          <label for="db_user">Database username</label>
          <input class="f-in" id="db_user" name="db_user" value="<?= e($form['db_user']) ?>" required>
        </div>
        <div>
          <label for="db_pass">Database password</label>
          <input class="f-in" id="db_pass" name="db_pass" type="password" autocomplete="new-password">
        </div>
      </div>
    </div>

    <div class="card">
      <h2>Website</h2>
      <div class="grid">
        <div>
          <label for="site_name">Website name</label>
          <input class="f-in" id="site_name" name="site_name" value="<?= e($form['site_name']) ?>" required>
        </div>
        <div>
          <label for="site_logo">Website logo (optional)</label>
          <input class="f-in" id="site_logo" name="site_logo" type="file" accept="image/*">
          <p class="hint">PNG/JPG/WEBP, max 1 MB.</p>
        </div>
      </div>
      <fieldset style="margin:16px 0 0;padding:0;border:0">
        <legend style="font-size:13px;font-weight:600;margin-bottom:6px">Install Demo Data</legend>
        <div class="check">
          <input type="radio" id="demo_on" name="demo_data" value="1" <?= $form['demo_data'] === '1' ? 'checked' : '' ?>>
          <label for="demo_on" style="font-weight:500;margin:0">ON</label>
        </div>
        <div class="check" style="margin-top:6px">
          <input type="radio" id="demo_off" name="demo_data" value="0" <?= $form['demo_data'] === '1' ? '' : 'checked' ?>>
          <label for="demo_off" style="font-weight:500;margin:0">OFF</label>
        </div>
        <p class="hint" style="margin:6px 0 0 22px">ON adds sample products, categories and homepage content. OFF starts empty.</p>
      </fieldset>
    </div>

    <div class="card">
      <h2>Administrator account</h2>
      <div class="grid">
        <div>
          <label for="admin_email">Admin email</label>
          <input class="f-in" id="admin_email" name="admin_email" type="email" value="<?= e($form['admin_email']) ?>" required>
        </div>
        <div>
          <label for="admin_password">Admin password</label>
          <input class="f-in" id="admin_password" name="admin_password" type="password" required
                 minlength="<?= (int)sh_password_min_length('admin') ?>" maxlength="200"
                 autocomplete="new-password" aria-describedby="pw-rules">
          <p class="hint" id="pw-rules">At least <?= (int)sh_password_min_length('admin') ?> characters. Any characters you like.</p>
          <p class="pw-live" id="pw-live" hidden></p>
        </div>
        <div>
          <label for="admin_password2">Confirm password</label>
          <input class="f-in" id="admin_password2" name="admin_password2" type="password" required>
        </div>
      </div>
    </div>

    <button class="btn" type="submit" <?= $reqOk ? '' : 'disabled' ?>>Install ShopHaat</button>
  </form>
<?php endif; // end restricted-mode / full-form branch ?>
<?php endif; ?>
</div>

<script<?= sh_csp_nonce_attr() ?>>
(function () {
  var pw = document.getElementById('admin_password');
  var pw2 = document.getElementById('admin_password2');
  var live = document.getElementById('pw-live');
  if (!pw || !live) { return; }

  var MIN = <?= (int)sh_password_min_length('admin') ?>;

  function evaluate() {
    var v = pw.value;
    if (v === '') { live.hidden = true; pw.setCustomValidity(''); return; }
    live.hidden = false;
    if (v.length >= MIN) {
      live.textContent = 'Password length is fine.';
      live.className = 'pw-live pw-live--ok';
      pw.setCustomValidity('');
    } else {
      live.textContent = 'At least ' + MIN + ' characters (' + (MIN - v.length) + ' more).';
      live.className = 'pw-live pw-live--bad';
      pw.setCustomValidity('Password must be at least ' + MIN + ' characters.');
    }
  }
  pw.addEventListener('input', evaluate);

  if (pw2) {
    function match() {
      pw2.setCustomValidity(pw2.value !== '' && pw2.value !== pw.value ? 'The two passwords do not match.' : '');
    }
    pw2.addEventListener('input', match);
    pw.addEventListener('input', match);
  }
})();
</script>
</body>
</html>
