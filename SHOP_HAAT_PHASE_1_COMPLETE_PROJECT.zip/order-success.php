<?php
/**
 * Order confirmation and live progress view.
 */
declare(strict_types=1);
require_once __DIR__ . '/config/config.php';
sh_require_installed();
require_once SH_ROOT . '/includes/payment.php';
require_once SH_ROOT . '/includes/order-timeline.php';

sh_session_start();
$orderId = sh_int($_GET['id'] ?? 0);

// Resume an expired session through Login without looking up the supplied order
// ID. The authenticated destination is resolved with an owner-scoped query.
if ($orderId > 0 && sh_user() === null && sh_customer_session_expired()) {
    sh_require_authenticated_customer('order-success.php?id=' . $orderId, false);
}
$order = $orderId > 0 ? sh_customer_order_get($orderId) : null;

if ($order === null) {
    http_response_code(404);
    $pageTitle = 'Order not found';
    require_once SH_ROOT . '/includes/header.php';
    echo '<div class="sh-wrap"><div class="sh-empty" style="margin-top:20px">'
        . '<span class="sh-empty__icon">' . sh_icon('x-circle', 26) . '</span>'
        . '<h1 class="sh-empty__title">Order not found</h1>'
        . '<p class="sh-empty__text">We could not find this order, or you do not have permission to view it.</p>'
        . '<a class="sh-btn" href="' . e(sh_url('index.php')) . '">Back to homepage</a></div></div>';
    require_once SH_ROOT . '/includes/footer.php';
    exit;
}

$items = sh_order_items($orderId);
// Preserve the saved payment route and map progress from persisted order and
// payment states. This is shared with Order Details and public tracking.
$payment = sh_order_latest_payment($orderId);
$timeline = sh_order_timeline($order, $payment, $items);
$isCod = (bool)$timeline['is_cod'];
$timelineProblem = is_array($timeline['problem'] ?? null) ? $timeline['problem'] : null;
$rejected = $timelineProblem !== null && ($timelineProblem['severity'] ?? '') === 'error';
$paymentDone = $isCod || in_array((string)$timeline['payment_status'], ['verified', 'refunded'], true);

$pageTitle = 'Order ' . $order['order_number'];
$pageDescription = 'Your order confirmation.';
require_once SH_ROOT . '/includes/header.php';
?>
<div class="sh-wrap">
  <div class="sh-steps" style="margin-top:12px">
    <span class="sh-steps__item sh-steps__item--done"><span class="sh-steps__num"><?= sh_icon('check-circle', 12) ?></span> Cart</span>
    <span class="sh-steps__sep"></span>
    <span class="sh-steps__item sh-steps__item--done"><span class="sh-steps__num"><?= sh_icon('check-circle', 12) ?></span> Checkout</span>
    <span class="sh-steps__sep"></span>
    <?php if ($isCod || (string)$timeline['payment_status'] !== 'unpaid'): ?>
      <span class="sh-steps__item sh-steps__item--done"><span class="sh-steps__num"><?= sh_icon('check-circle', 12) ?></span> Payment</span>
    <?php else: ?>
      <span class="sh-steps__item sh-steps__item--on"><span class="sh-steps__num">3</span> Payment</span>
    <?php endif; ?>
    <span class="sh-steps__sep"></span>
    <?php if ($paymentDone && !$rejected): ?>
      <span class="sh-steps__item sh-steps__item--done"><span class="sh-steps__num"><?= sh_icon('check-circle', 12) ?></span> Confirmation</span>
    <?php else: ?>
      <span class="sh-steps__item sh-steps__item--on"><span class="sh-steps__num">4</span> Confirmation</span>
    <?php endif; ?>
  </div>

  <div class="sh-section" style="text-align:center;padding:26px 16px">
    <span style="display:inline-grid;place-items:center;width:62px;height:62px;border-radius:50%;
      background:<?= $rejected ? 'var(--sh-bad-soft)' : 'var(--sh-ok-soft)' ?>;
      color:<?= $rejected ? 'var(--sh-bad)' : 'var(--sh-ok)' ?>;margin-bottom:12px">
      <?= sh_icon($rejected ? 'x-circle' : 'check-circle', 30) ?>
    </span>
    <h1 style="font-size:21px;font-weight:800;margin-bottom:6px">
      <?= $timelineProblem !== null ? e((string)$timelineProblem['label']) : 'Thank you — your order is confirmed' ?>
    </h1>
    <p style="font-size:14px;color:var(--sh-muted);max-width:520px;margin:0 auto 12px">
      <?php if ($timelineProblem !== null): ?>
        <?= e((string)$timelineProblem['detail']) ?>
      <?php elseif ($isCod): ?>
        Order <strong><?= e($order['order_number']) ?></strong> has been placed. Please keep <?= e(sh_money($order['total'])) ?> ready for the delivery agent.
      <?php elseif (sh_order_timeline_payment_status((string)$order['payment_status']) === 'submitted'): ?>
        Order <strong><?= e($order['order_number']) ?></strong> has been placed and your payment is awaiting verification.
      <?php elseif (sh_order_timeline_payment_status((string)$order['payment_status']) === 'verified'): ?>
        Order <strong><?= e($order['order_number']) ?></strong> is paid and being processed.
      <?php else: ?>
        Order <strong><?= e($order['order_number']) ?></strong> has been created. Please complete the payment to continue.
      <?php endif; ?>
    </p>
    <div style="display:flex;gap:9px;justify-content:center;flex-wrap:wrap">
      <a class="sh-btn sh-btn--ghost" href="<?= e(sh_url('order-details.php?id=' . $orderId)) ?>"><?= sh_icon('eye', 15) ?> Order details</a>
      <?php if ((string)$timeline['payment_status'] === 'unpaid' && !$isCod): ?>
        <a class="sh-btn" href="<?= e(sh_url('payment.php?id=' . $orderId)) ?>"><?= sh_icon('credit-card', 15) ?> Complete payment</a>
      <?php endif; ?>
      <a class="sh-btn sh-btn--ghost" href="<?= e(sh_url('products.php')) ?>">Continue shopping</a>
    </div>
  </div>

  <div class="sh-section">
    <div class="sh-section__head"><h2 class="sh-section__title"><?= sh_icon('truck', 18) ?> Order Progress</h2></div>
    <?= sh_order_timeline_problem_render($timeline) ?>
    <div style="margin-top:<?= !empty($timeline['problem']) ? '14px' : '0' ?>"><?= sh_order_timeline_render($timeline) ?></div>
  </div>

  <div class="sh-cartlayout">
    <div class="sh-section">
      <div class="sh-section__head"><h2 class="sh-section__title"><?= sh_icon('package', 18) ?> Items</h2></div>
      <?php foreach ($items as $it): ?>
        <div class="sh-mini-item">
          <img class="sh-mini-item__img" src="<?= e(sh_product_image($it['product_image'])) ?>" alt="" loading="lazy">
          <div class="sh-mini-item__name"><?= e($it['product_name']) ?>
            <?php $colour = sh_order_item_colour_text($it); ?>
            <?php if ($colour !== ''): ?><div class="sh-mini-item__qty">Colour: <?= e($colour) ?></div><?php endif; ?>
            <div class="sh-mini-item__qty">Qty <?= (int)$it['quantity'] ?> × <?= e(sh_money($it['unit_price'])) ?></div>
          </div>
          <span class="sh-mini-item__price"><?= e(sh_money($it['line_total'])) ?></span>
        </div>
      <?php endforeach; ?>
    </div>

    <aside class="sh-summary">
      <h2 class="sh-summary__title">Payment Summary</h2>
      <div class="sh-summary__row"><span>Order status</span><span class="sh-badge <?= e(sh_status_class($order['status'])) ?>"><?= e(sh_status_label($order['status'])) ?></span></div>
      <div class="sh-summary__row"><span>Payment status</span><span class="sh-badge <?= e(sh_status_class($order['payment_status'])) ?>"><?= e(sh_status_label($order['payment_status'])) ?></span></div>
      <div class="sh-summary__row"><span>Method</span><span><?= e($order['payment_method_name']) ?></span></div>
      <div class="sh-summary__row"><span>Subtotal</span><span><?= e(sh_money($order['subtotal'])) ?></span></div>
      <?php if ((float)$order['discount'] > 0): ?>
        <div class="sh-summary__row sh-summary__row--discount"><span>Discount</span><span>-<?= e(sh_money($order['discount'])) ?></span></div>
      <?php endif; ?>
      <div class="sh-summary__row"><span>Delivery</span><span><?= (float)$order['delivery_fee'] > 0 ? e(sh_money($order['delivery_fee'])) : 'Free' ?></span></div>
      <div class="sh-summary__total"><span>Total</span><span><?= e(sh_money($order['total'])) ?></span></div>
    </aside>
  </div>
</div>
<?php require_once SH_ROOT . '/includes/footer.php'; ?>
