<?php
/**
 * Customer authentication + cart ownership.
 */

function sh_login_user(int $userId): void
{
    sh_session_start();
    session_regenerate_id(true);
    $_SESSION['user_id'] = $userId;
    $_SESSION['user_login_at'] = time();
    // Rotate the form token at the authentication boundary. The next rendered
    // page receives a fresh token; no state-changing request is replayed.
    unset($_SESSION['csrf_token'], $_SESSION['sh_auth_expired']);
    sh_customer_auth_hint_set();
    sh_query('UPDATE users SET last_login_at = NOW() WHERE id = ?', [$userId]);
    sh_merge_guest_cart($userId);
}

function sh_logout_user(): void
{
    sh_session_start();
    unset($_SESSION['user_id'], $_SESSION['user_login_at'], $_SESSION['sh_auth_expired'], $_SESSION['csrf_token']);
    sh_customer_auth_hint_clear();
    session_regenerate_id(true);
}

/** Mark an invalid or expired browser session without exposing account details. */
function sh_forget_customer_session(bool $expired = false): void
{
    sh_session_start();
    unset($_SESSION['user_id'], $_SESSION['user_login_at'], $_SESSION['csrf_token']);
    if ($expired) { $_SESSION['sh_auth_expired'] = 1; }
    else { unset($_SESSION['sh_auth_expired']); }
}

/** One-time customer-facing notice used after a real authentication timeout. */
function sh_consume_customer_session_expired_notice(): bool
{
    if (!sh_customer_session_expired()) { return false; }
    // Do not leave a stale identity usable in the new request while the login
    // notice is being prepared. The hint is display-only and is cleared now.
    unset($_SESSION['user_id'], $_SESSION['user_login_at'], $_SESSION['csrf_token'], $_SESSION['sh_auth_expired']);
    sh_customer_auth_hint_clear();
    sh_flash('info', 'Your session has expired. Please log in again to continue.');
    return true;
}

function sh_user(): ?array
{
    static $user = null;
    static $identity = null;

    sh_session_start();
    $id = (int)($_SESSION['user_id'] ?? 0);
    $loginAt = (int)($_SESSION['user_login_at'] ?? 0);
    // A login/logout/session regeneration can happen later in the same PHP
    // request (for example during an OAuth callback). Cache only while the
    // session identity itself is unchanged; otherwise a guest cart could be
    // selected after a successful customer login.
    $currentIdentity = $id . ':' . $loginAt;
    $now = time();
    $stillValid = $id <= 0 || ($loginAt > 0 && $loginAt <= $now && ($now - $loginAt) <= sh_session_ttl());
    if ($identity === $currentIdentity && $stillValid) { return $user; }
    $identity = $currentIdentity;
    $user = null;
    if ($id <= 0) { return null; }

    // Server-side 24h session: a missing timestamp is treated as expired too.
    // That prevents a stale/partially-written session from reaching profile code
    // with a null customer record.
    if ($loginAt <= 0 || $loginAt > $now || ($now - $loginAt) > sh_session_ttl()) {
        sh_forget_customer_session(true);
        return null;
    }
    try {
        $u = sh_one('SELECT * FROM users WHERE id = ? LIMIT 1', [$id]);
        if ($u !== null) { unset($u['password_hash'], $u['firebase_secret']); }
    } catch (Throwable $e) {
        sh_log_exception($e, 'auth');
        return null;
    }
    if ($u === null || $u['status'] !== 'active') {
        sh_forget_customer_session(true);
        return null;
    }
    $user = $u;
    return $user;
}

function sh_user_id(): int
{
    $u = sh_user();
    return $u ? (int)$u['id'] : 0;
}

/** Shared customer guard; identity always comes from the authenticated session. */
function sh_require_authenticated_customer(string $redirectTo = '', bool $requireVerified = true): array
{
    return sh_require_login($redirectTo, $requireVerified);
}

/** Load an address only when the current session customer owns it. */
function sh_customer_address_get(int $addressId): ?array
{
    $userId = sh_user_id();
    if ($addressId <= 0 || $userId <= 0) { return null; }
    return sh_one('SELECT * FROM addresses WHERE id = ? AND user_id = ? LIMIT 1', [$addressId, $userId]);
}

/**
 * Does the authenticated customer own this address? The supplied address ID is
 * only a selector; the owner is always derived from the server session.
 */
function sh_customer_owns_address(int $addressId): bool
{
    return sh_customer_address_get($addressId) !== null;
}

/**
 * Restrict a post-login destination to a customer-facing internal page.
 * Authentication pages and admin/API endpoints are intentionally excluded to
 * prevent loops and cross-surface redirects.
 */
function sh_customer_return_target(string $raw, string $fallback = 'account.php'): string
{
    $target = sh_safe_redirect($raw, '');
    if ($target === '') { return $fallback; }

    $path = (string)(parse_url($target, PHP_URL_PATH) ?? '');
    // sh_safe_redirect() rejects dangerous decoded values, but preserve the
    // encoded target itself for a legitimate customer URL. Decode here too so
    // admin/login routes cannot bypass the allowlist as admin%2Forders.php.
    for ($i = 0; $i < 2; $i++) {
        $decoded = rawurldecode($path);
        if ($decoded === $path) { break; }
        $path = $decoded;
    }
    $path = strtolower(ltrim(explode('?', $path, 2)[0], '/'));
    if ($path === '' || preg_match('~^(?:admin|api|install)(?:/|\.php$|$)~', $path) === 1) {
        return $fallback;
    }
    $blocked = [
        'login.php', 'register.php', 'logout.php', 'otp.php', 'forgot-password.php',
        'reset-password.php', 'verify-email.php', 'auth/google/login.php', 'auth/google/callback.php',
    ];
    return in_array($path, $blocked, true) ? $fallback : $target;
}

function sh_login_url(string $returnTo = 'account.php'): string
{
    $target = sh_customer_return_target($returnTo, 'account.php');
    return 'login.php?redirect=' . rawurlencode($target);
}

/** @return array{success:bool,error:string,auth_required:bool,session_expired:bool,login_url:string} */
function sh_customer_auth_required_payload(string $returnTo = '', ?bool $expired = null): array
{
    $expired = $expired ?? sh_customer_session_expired();
    return [
        'success' => false,
        'error' => $expired
            ? 'Your session has expired. Please log in again to continue.'
            : 'Please sign in to continue.',
        'auth_required' => true,
        'session_expired' => $expired,
        'login_url' => sh_url(sh_login_url($returnTo)),
    ];
}

/**
 * Does this customer account require email verification before accessing protected areas?
 *
 * True only when email verification is enabled by the administrator, the account
 * uses a real (non-synthetic) email address, and email_verified is not 1.
 */
function sh_user_needs_email_verification(?array $user = null): bool
{
    if ($user === null) {
        $user = sh_user();
    }
    if ($user === null) {
        return false;
    }
    if (sh_auth_mode() !== 'email_password') {
        return false;
    }

    if (!function_exists('sh_email_verify_enabled')) {
        require_once SH_ROOT . '/includes/mail.php';
    }
    if (!sh_email_verify_enabled()) {
        return false;
    }

    $email = trim((string)($user['email'] ?? ''));
    if ($email === '' || (function_exists('sh_is_synthetic_email') && sh_is_synthetic_email($email))) {
        return false;
    }
    if (function_exists('sh_valid_email')) {
        if (!sh_valid_email($email)) { return false; }
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return false;
    }

    return empty($user['email_verified']);
}

function sh_require_login(string $redirectTo = '', bool $requireVerified = true): array
{
    $u = sh_user();
    if ($u === null) {
        $target = $redirectTo !== '' ? $redirectTo : (string)($_SERVER['REQUEST_URI'] ?? '');
        $expired = sh_customer_session_expired();
        if (sh_wants_json()) {
            sh_json(sh_customer_auth_required_payload($target, $expired), 401);
        }

        if ($expired) { sh_consume_customer_session_expired_notice(); }
        sh_redirect(sh_login_url($target));
    }

    if ($requireVerified && sh_user_needs_email_verification($u)) {
        $target = $redirectTo !== '' ? $redirectTo : (string)($_SERVER['REQUEST_URI'] ?? '');
        $target = sh_customer_return_target($target, 'account.php');
        if (function_exists('sh_email_verify_pending_set')) {
            sh_email_verify_pending_set($u, $target, 'protected');
        }
        if (sh_wants_json()) {
            sh_json([
                'success'          => false,
                'error'            => 'Please verify your email address to continue.',
                'email_unverified' => true,
                'verify_url'       => sh_url('verify-email.php'),
            ], 403);
        }
        sh_flash('warning', 'Please verify your email address before continuing.');
        sh_redirect('verify-email.php');
    }

    return $u;
}

/**
 * Guest carts are keyed by a random cookie token, then merged on login.
 */
function sh_cart_token(): string
{
    sh_session_start();
    if (!empty($_SESSION['cart_token'])) { return $_SESSION['cart_token']; }
    $cookie = $_COOKIE['sh_cart'] ?? '';
    if (is_string($cookie) && preg_match('/^[a-f0-9]{64}$/', $cookie)) {
        $_SESSION['cart_token'] = $cookie;
        return $cookie;
    }
    $token = bin2hex(random_bytes(32));
    $_SESSION['cart_token'] = $token;
    if (!headers_sent()) {
        // Cart ownership is deliberately independent of authentication so an
        // automatic logout never discards a customer's selected items.
        setcookie('sh_cart', $token, sh_site_cookie_options(time() + 86400 * 30));
    }
    return $token;
}

/** Returns the current cart id, creating one when needed. */
function sh_cart_id(bool $create = true): int
{
    // The request can transition from guest to authenticated after
    // session_regenerate_id(). Cache by owner rather than one unqualified ID so
    // a guest cart ID can never be reused for the newly signed-in customer.
    static $ids = [];
    $uid = sh_user_id();
    if ($uid > 0) {
        $key = 'user:' . $uid;
        if (isset($ids[$key]) && $ids[$key] > 0) { return $ids[$key]; }
        $row = sh_one('SELECT id FROM cart WHERE user_id = ? ORDER BY id DESC LIMIT 1', [$uid]);
        if ($row) { return $ids[$key] = (int)$row['id']; }

        // If the first login request could not finish its merge (for example a
        // transient database fault), keep retrying from ordinary cart reads.
        // The guest cart remains untouched until this succeeds, so it is never
        // silently replaced with an empty authenticated cart.
        $guestToken = $_SESSION['cart_token'] ?? ($_COOKIE['sh_cart'] ?? '');
        if (is_string($guestToken) && preg_match('/^[a-f0-9]{64}$/', $guestToken)) {
            sh_merge_guest_cart($uid);
            $row = sh_one('SELECT id FROM cart WHERE user_id = ? ORDER BY id DESC LIMIT 1', [$uid]);
            if ($row) { return $ids[$key] = (int)$row['id']; }
        }
        if (!$create) { return 0; }
        return $ids[$key] = sh_insert('cart', ['user_id' => $uid]);
    }

    $token = sh_cart_token();
    $key = 'guest:' . $token;
    if (isset($ids[$key]) && $ids[$key] > 0) { return $ids[$key]; }
    $row = sh_one('SELECT id FROM cart WHERE session_token = ? AND user_id IS NULL ORDER BY id DESC LIMIT 1', [$token]);
    if ($row) { return $ids[$key] = (int)$row['id']; }
    if (!$create) { return 0; }
    return $ids[$key] = sh_insert('cart', ['session_token' => $token]);
}

/** Whether the additive colour-variant cart column is present on this install. */
function sh_cart_has_variant_column(): bool
{
    static $has = null;
    if ($has !== null) { return $has; }
    try {
        $has = function_exists('sh_table_has_column') && sh_table_has_column('cart_items', 'variant');
    } catch (Throwable $e) {
        $has = false;
    }
    return $has;
}

/**
 * Move a guest cart into an authenticated customer's cart atomically. A login
 * session ID regeneration retains the random cart token; this transaction makes
 * its one-time migration safe even when the customer already has a cart.
 */
function sh_merge_guest_cart(int $userId): void
{
    sh_session_start();
    $token = $_SESSION['cart_token'] ?? ($_COOKIE['sh_cart'] ?? '');
    if ($userId <= 0 || !is_string($token) || !preg_match('/^[a-f0-9]{64}$/', $token)) { return; }

    $pdo = null;
    $transactionStarted = false;
    try {
        $pdo = sh_db();
        if ($pdo->inTransaction()) {
            // Do not attach an authentication/cart migration to someone else's
            // business transaction. The guest rows stay intact rather than
            // becoming partially moved.
            sh_log_line('cart-merge', 'Deferred guest-cart merge because a transaction is active.');
            return;
        }
        $pdo->beginTransaction();
        $transactionStarted = true;

        // Serialize migrations for one customer. cart.user_id is indexed but is
        // intentionally not globally unique on older installs, so locking the
        // owning user prevents two concurrent sign-ins from creating separate
        // user carts and leaving one of their guest carts invisible.
        $owner = sh_one('SELECT id FROM users WHERE id = ? LIMIT 1 FOR UPDATE', [$userId]);
        if ($owner === null) { throw new DomainException('Customer account not found.'); }
        $guest = sh_one(
            'SELECT id FROM cart WHERE session_token = ? AND user_id IS NULL ORDER BY id DESC LIMIT 1 FOR UPDATE',
            [$token]
        );
        if ($guest === null) {
            if (!$pdo->inTransaction()) { throw new LogicException('Guest-cart merge transaction ended unexpectedly before commit.'); }
            $pdo->commit();
            $transactionStarted = false;
            return;
        }
        $guestId = (int)$guest['id'];
        // auth.php is also used by Login without loading cart.php, so do not
        // assume the cart module's SH_MAX_QTY constant is already defined.
        $maxQty = defined('SH_MAX_QTY') ? (int)SH_MAX_QTY : 20;
        $own = sh_one('SELECT id FROM cart WHERE user_id = ? ORDER BY id DESC LIMIT 1 FOR UPDATE', [$userId]);
        if ($own === null) {
            sh_query('UPDATE cart SET user_id = ?, session_token = NULL WHERE id = ?', [$userId, $guestId]);
        } else {
            $ownId = (int)$own['id'];
            $hasVariant = sh_cart_has_variant_column();
            $select = $hasVariant
                ? 'SELECT product_id, variant, quantity FROM cart_items WHERE cart_id = ? FOR UPDATE'
                : "SELECT product_id, '' AS variant, quantity FROM cart_items WHERE cart_id = ? FOR UPDATE";
            foreach (sh_all($select, [$guestId]) as $it) {
                $variant = trim(mb_substr((string)($it['variant'] ?? ''), 0, 190));
                if ($hasVariant) {
                    sh_query(
                        'INSERT INTO cart_items (cart_id, product_id, variant, quantity) VALUES (?,?,?,?)
                         ON DUPLICATE KEY UPDATE quantity = LEAST(quantity + VALUES(quantity), ?)',
                        [$ownId, (int)$it['product_id'], $variant, max(1, min($maxQty, (int)$it['quantity'])), $maxQty]
                    );
                } else {
                    // Legacy schema before the colour migration: preserve the
                    // original product-only cart line rather than failing login.
                    sh_query(
                        'INSERT INTO cart_items (cart_id, product_id, quantity) VALUES (?,?,?)
                         ON DUPLICATE KEY UPDATE quantity = LEAST(quantity + VALUES(quantity), ?)',
                        [$ownId, (int)$it['product_id'], max(1, min($maxQty, (int)$it['quantity'])), $maxQty]
                    );
                }
            }
            sh_query('DELETE FROM cart WHERE id = ?', [$guestId]);
        }

        if (!$pdo->inTransaction()) {
            throw new LogicException('Guest-cart merge transaction ended unexpectedly.');
        }
        $pdo->commit();
        $transactionStarted = false;
    } catch (Throwable $e) {
        if ($transactionStarted && $pdo instanceof PDO && $pdo->inTransaction()) {
            try { $pdo->rollBack(); }
            catch (Throwable $rollbackError) { sh_log_exception($rollbackError, 'cart-merge-rollback'); }
        }
        sh_log_exception($e, 'cart-merge');
    }
}

/* ---------- Shared login throttling ----------------------------------
 * Used by BOTH the customer and admin sign-in forms, so it lives here
 * in auth.php rather than admin-auth.php.
 * ------------------------------------------------------------------ */
/** Simple session-based login throttle (no extra table needed). */
function sh_login_throttled(string $bucket, int $max = 6, int $window = 900): bool
{
    sh_session_start();
    $key = 'throttle_' . $bucket;
    $d = $_SESSION[$key] ?? ['n' => 0, 't' => time()];
    if (time() - (int)$d['t'] > $window) { return false; }
    return (int)$d['n'] >= $max;
}
function sh_login_fail(string $bucket): void
{
    sh_session_start();
    $key = 'throttle_' . $bucket;
    $d = $_SESSION[$key] ?? ['n' => 0, 't' => time()];
    if (time() - (int)$d['t'] > 900) { $d = ['n' => 0, 't' => time()]; }
    $d['n'] = (int)$d['n'] + 1;
    $_SESSION[$key] = $d;
}
function sh_login_reset(string $bucket): void
{
    sh_session_start();
    unset($_SESSION['throttle_' . $bucket]);
}

/* ---------- Database-backed authentication throttling ----------------
 * The counters above live in the PHP session, and a session is discarded the
 * moment the attacker drops the cookie — so on its own it does not slow a
 * credential-stuffing run down at all.
 *
 * These helpers additionally count recent failures in the `security_logs`
 * audit table, which an unauthenticated attacker cannot clear or edit. Both
 * checks run together: the session counter stays as the fast first line, the
 * table provides the limit that actually holds.
 *
 * Failure to read the audit table fails OPEN on purpose: a store must never
 * become impossible to sign in to because a logging table is unavailable.
 * ------------------------------------------------------------------ */

/** Pseudonymous, non-reversible handle for an account identifier used in logs. */
function sh_auth_identity_hash(string $identity): string
{
    return substr(hash('sha256', 'sh-auth|' . mb_strtolower(trim($identity))), 0, 32);
}

/**
 * Count recent authentication failures from the audit table.
 *
 * @param string      $event        audit event name to count
 * @param string      $ip           client IP
 * @param string|null $identityHash account handle, or null to count by IP only
 * @param int         $window       look-back window in seconds
 */
function sh_auth_failure_count(string $event, string $ip, ?string $identityHash, int $window): int
{
    try {
        if (!sh_table_exists('security_logs')) { return 0; }
        if ($identityHash === null) {
            return (int)sh_val(
                'SELECT COUNT(*) FROM security_logs
                  WHERE event = ? AND ip_address = ? AND created_at > (NOW() - INTERVAL ? SECOND)',
                [$event, $ip, $window],
                0
            );
        }
        // metadata holds a JSON document; the identity is a hex hash, so the
        // LIKE pattern cannot contain wildcards from user input.
        return (int)sh_val(
            'SELECT COUNT(*) FROM security_logs
              WHERE event = ? AND ip_address = ?
                AND metadata LIKE ?
                AND created_at > (NOW() - INTERVAL ? SECOND)',
            [$event, $ip, '%"email_sha":"' . $identityHash . '"%', $window],
            0
        );
    } catch (Throwable $e) {
        sh_log_exception($e, 'auth-throttle');
        return 0;
    }
}

/**
 * Is this sign-in attempt blocked? Checks the caller's IP and, when an account
 * identifier was supplied, that identifier as well.
 *
 * @param string $event  audit event used for failures ('login_failed' or 'admin_login_failed')
 * @param string $identity submitted email address (may be empty)
 */
function sh_auth_throttle_blocked(string $event, string $identity, int $ipMax = 25, int $idMax = 8, int $window = 900): bool
{
    $ip = function_exists('sh_client_ip') ? sh_client_ip() : (string)($_SERVER['REMOTE_ADDR'] ?? '');
    if (sh_auth_failure_count($event, $ip, null, $window) >= $ipMax) { return true; }
    if ($identity !== '') {
        $hash = sh_auth_identity_hash($identity);
        if (sh_auth_failure_count($event, $ip, $hash, $window) >= $idMax) { return true; }
    }
    return false;
}

/**
 * Record one failed authentication attempt in both the session counter and the
 * audit table. Stores only a masked identifier plus a pseudonymous hash — never
 * the submitted password, and never the full address.
 */
function sh_auth_failure_record(string $bucket, string $event, string $identity, ?int $userId = null, array $meta = []): void
{
    sh_login_fail($bucket);
    if (function_exists('sh_security_log')) {
        $meta['email_sha'] = $identity !== '' ? sh_auth_identity_hash($identity) : '';
        if ($identity !== '') {
            $meta['email'] = mb_substr($identity, 0, 3) . '***';
        }
        sh_security_log($event, $userId, $meta);
    }
}

/** Count an abuse-prone action recorded elsewhere in security_logs. */
function sh_auth_action_count(string $event, int $window): int
{
    $ip = function_exists('sh_client_ip') ? sh_client_ip() : (string)($_SERVER['REMOTE_ADDR'] ?? '');
    return sh_auth_failure_count($event, $ip, null, $window);
}
