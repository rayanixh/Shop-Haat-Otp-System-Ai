/*
 * ShopHaat support chat widget.
 *
 * Plain fetch + bounded polling (5s, only while the panel is open). The
 * panel is viewport-fixed and bottom-anchored: document scrolling never moves
 * it and never gets locked. Only the message log scrolls internally; the
 * website outside the chat keeps its own independent scroll. Sends are
 * idempotent: every message carries a client_msg_id the server dedupes.
 *
 * The launcher is a circular button that opens only the configured support
 * channels. The AI Assistant option uses the existing chat panel; configured
 * Messenger and WhatsApp options remain ordinary external links.
 */
(function () {
  'use strict';

  var fab = document.getElementById('sh-schat-fab');
  var sheet = document.getElementById('sh-schat-sheet');
  if (!fab) { return; }

  var menu = document.getElementById('sh-schat-menu');
  var liveOpt = document.getElementById('sh-schat-opt-chat');

  // Stores with only Messenger and/or WhatsApp have a launcher menu but no AI
  // popup or chat API configuration. Keep those external links usable without
  // emitting an empty panel or running any chat behavior.
  if (!sheet) {
    var externalMenuOpen = false;
    function closeExternalMenu() {
      if (!menu || !externalMenuOpen) { return; }
      externalMenuOpen = false;
      if (menu.contains(document.activeElement)) { fab.focus(); }
      menu.classList.remove('is-open');
      menu.setAttribute('aria-hidden', 'true');
      fab.setAttribute('aria-expanded', 'false');
      window.setTimeout(function () { if (!externalMenuOpen) { menu.hidden = true; } }, 240);
    }
    fab.addEventListener('click', function (event) {
      event.preventDefault();
      if (!menu) { return; }
      if (externalMenuOpen) { closeExternalMenu(); return; }
      externalMenuOpen = true;
      menu.hidden = false;
      menu.setAttribute('aria-hidden', 'false');
      fab.setAttribute('aria-expanded', 'true');
      void menu.offsetWidth;
      menu.classList.add('is-open');
      var first = menu.querySelector('[role="menuitem"]');
      if (first) { first.focus(); }
    });
    if (menu) {
      menu.addEventListener('keydown', function (event) {
        var items = Array.prototype.slice.call(menu.querySelectorAll('[role="menuitem"]'));
        var at = items.indexOf(document.activeElement);
        if (!items.length) { return; }
        if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
          event.preventDefault();
          items[(at + (event.key === 'ArrowDown' ? 1 : items.length - 1)) % items.length].focus();
        } else if (event.key === 'Escape' || event.key === 'Tab') { closeExternalMenu(); }
      });
    }
    document.addEventListener('pointerdown', function (event) {
      if (externalMenuOpen && !menu.contains(event.target) && !fab.contains(event.target)) { closeExternalMenu(); }
    }, true);
    document.addEventListener('keydown', function (event) {
      if (event.key === 'Escape') { closeExternalMenu(); }
    });
    return;
  }

  // A position:fixed element is only viewport-fixed when no ancestor creates
  // a containing block (transform/filter/perspective/contain) or clips it.
  // Keep both nodes direct children of <body> regardless of where the theme
  // mounted the widget partial.
  if (document.body) {
    if (fab.parentNode !== document.body) { document.body.appendChild(fab); }
    if (menu && menu.parentNode !== document.body) { document.body.appendChild(menu); }
    if (sheet.parentNode !== document.body) { document.body.appendChild(sheet); }
  }

  var cfg = { endpoint: '', max: 2000 };
  try { cfg = Object.assign(cfg, JSON.parse(sheet.getAttribute('data-config') || '{}')); } catch (e) {}
  if (!cfg.endpoint) { return; }

  var listEl = document.getElementById('sh-schat-messages');
  var suggestEl = document.getElementById('sh-schat-suggest');
  var form = document.getElementById('sh-schat-form');
  var input = document.getElementById('sh-schat-input');
  var sendBtn = document.getElementById('sh-schat-send');
  var statusEl = document.getElementById('sh-schat-status');
  var badgeEl = document.getElementById('sh-schat-badge');
  var handoffBtn = document.getElementById('sh-schat-handoff');

  // The composer has a fixed CSS height and its own internal scrollbar.
  // Clear any stale inline height/overflow written by an older cached script;
  // no widget event listener changes those dimensions while the user types.
  if (input) {
    input.style.removeProperty('height');
    input.style.removeProperty('overflow-y');
  }

  var convId = 0, lastId = 0, started = false, isOpen = false, human = false;
  var pollTimer = null, seen = {}, unread = 0, sentOnce = false;
  var menuOpen = false, menuHideTimer = null;

  function el(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) { n.className = cls; }
    if (text != null) { n.textContent = text; }
    return n;
  }

  function newClientId() {
    if (window.crypto && typeof window.crypto.randomUUID === 'function') {
      return window.crypto.randomUUID();
    }
    try {
      var b = new Uint8Array(16);
      window.crypto.getRandomValues(b);
      b[6] = (b[6] & 0x0f) | 0x40;
      b[8] = (b[8] & 0x3f) | 0x80;
      var hex = Array.from(b).map(function (x) { return x.toString(16).padStart(2, '0'); }).join('');
      return hex.slice(0, 8) + '-' + hex.slice(8, 12) + '-' + hex.slice(12, 16) + '-' + hex.slice(16, 20) + '-' + hex.slice(20);
    } catch (e) {
      // This ID is an idempotency key, not an authorization secret.
      return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
        var r = Math.random() * 16 | 0;
        return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
      });
    }
  }

  function post(action, fields) {
    var body = new URLSearchParams();
    body.set('action', action);
    body.set('csrf_token', window.SH_CSRF || '');
    Object.keys(fields || {}).forEach(function (k) { body.set(k, fields[k]); });
    return fetch(cfg.endpoint, {
      method: 'POST', body: body, credentials: 'same-origin',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' }
    }).then(function (r) {
      return r.json().catch(function () { return { ok: false, error: 'bad_response' }; }).then(function (data) {
        if (!r.ok || !data.ok) { var err = new Error(data.error || ('HTTP ' + r.status)); err.code = data.error || ''; err.status = r.status; throw err; }
        return data;
      });
    });
  }

  function errorText(err) {
    switch (err && err.code) {
      case 'rate_limited': return 'Too many messages in a short time — please wait a moment. / অনুগ্রহ করে একটু অপেক্ষা করুন।';
      case 'too_long': return 'That message is too long. Please shorten it and send again.';
      case 'support_disabled': return 'Support chat is currently unavailable. Please try again later.';
      default: return 'Could not send right now. Check your connection and use Retry — your message is kept.';
    }
  }

  function setStatus(text, isError) {
    statusEl.textContent = text || '';
    statusEl.classList.toggle('is-error', !!isError);
  }

  function timeOf(at) {
    var d = new Date(String(at || '').replace(' ', 'T'));
    if (isNaN(d.getTime())) { return ''; }
    return d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
  }

  function isLinkable(line) {
    if (!line || /\s/.test(line)) { return false; }
    try {
      var u = new URL(line, window.location.href);
      return (u.protocol === 'http:' || u.protocol === 'https:') && u.origin === window.location.origin && /\.php(\?|$)/.test(u.pathname + u.search);
    } catch (e) { return false; }
  }

  function bodyNodes(body) {
    var frag = document.createDocumentFragment();
    String(body || '').split('\n').forEach(function (line, i) {
      if (i > 0) { frag.appendChild(document.createElement('br')); }
      var trimmed = line.trim();
      if (isLinkable(trimmed)) {
        var a = el('a', 'sh-schat-link');
        a.href = trimmed;
        a.textContent = /product\.php/.test(trimmed) ? 'View product' : trimmed;
        frag.appendChild(a);
      } else {
        frag.appendChild(document.createTextNode(line));
      }
    });
    return frag;
  }

  function renderMessage(m) {
    if (m.id && seen[m.id]) { return null; }
    if (m.id) { seen[m.id] = true; lastId = Math.max(lastId, m.id); }
    if (m.kind === 'notice') {
      var n = el('div', 'sh-schat-notice');
      n.appendChild(bodyNodes(m.body));
      listEl.appendChild(n);
      return n;
    }
    var wrap = el('div', 'sh-schat-msg is-' + m.kind);
    var who = m.kind === 'customer' ? 'You' : (m.kind === 'agent' ? 'Support agent' : (m.ai ? 'AI assistant' : 'Support'));
    var meta = el('div', 'sh-schat-meta');
    meta.appendChild(el('span', 'sh-schat-who', who));
    var t = timeOf(m.at);
    if (t) { meta.appendChild(el('time', 'sh-schat-time', t)); }
    var bubble = el('div', 'sh-schat-bubble');
    bubble.appendChild(bodyNodes(m.body));
    wrap.appendChild(meta); wrap.appendChild(bubble);
    listEl.appendChild(wrap);
    return wrap;
  }

  function renderAll(messages) {
    (messages || []).forEach(renderMessage);
  }

  function setBadge() {
    badgeEl.hidden = unread <= 0;
    badgeEl.textContent = String(Math.min(99, unread));
  }

  function applyConversation(data) {
    if (data.conversation) {
      convId = data.conversation.id || convId;
      human = !!data.conversation.human;
      sheet.setAttribute('data-human', human ? '1' : '0');
      handoffBtn.hidden = human;
      var status = String(data.conversation.status || 'open');
      document.getElementById('sh-schat-new').hidden = !['resolved', 'closed'].includes(status);
    }
    if (Array.isArray(data.suggestions) && !sentOnce) {
      suggestEl.textContent = '';
      data.suggestions.forEach(function (s) {
        var b = el('button', 'sh-schat-chip', s);
        b.type = 'button';
        b.addEventListener('click', function () { input.value = s; form.requestSubmit(); });
        suggestEl.appendChild(b);
      });
    }
  }

  function keepInputVisible() {
    // Scroll ONLY the message log to its newest message. Never call
    // scrollIntoView() on a child of a fixed panel: that would scroll the
    // website behind the chat and make the whole page jump on every reply.
    try {
      if (typeof listEl.scrollTo === 'function') {
        listEl.scrollTo({ top: listEl.scrollHeight, block: 'end' });
      } else {
        listEl.scrollTop = listEl.scrollHeight;
      }
    } catch (e) {}
  }

  /**
   * Bottom-anchor the panel to the *visible* viewport. The mobile bottom nav
   * height is measured (minus its safe-area padding, which CSS re-adds via
   * env()), and visualViewport.height follows address-bar collapse and the
   * on-screen keyboard. No document scroll offset is ever read or written.
   */
  function syncViewport() {
    var bottom = 16;
    var nav = document.querySelector('.sh-bottomnav');
    if (nav) {
      var cs = window.getComputedStyle ? window.getComputedStyle(nav) : null;
      if (!cs || cs.display !== 'none') {
        var h = nav.getBoundingClientRect ? nav.getBoundingClientRect().height : 0;
        var pad = cs ? (parseFloat(cs.paddingBottom) || 0) : 0;
        if (h > 0) { bottom = Math.ceil(Math.max(0, h - pad)) + 8; }
      }
    }
    try {
      sheet.style.setProperty('--sh-schat-bottom', bottom + 'px');
      var vv = window.visualViewport;
      if (vv && typeof vv.height === 'number' && vv.height > 0) {
        sheet.style.setProperty('--sh-schat-vh', Math.floor(vv.height) + 'px');
      }
    } catch (e) {}
  }

  function showTyping() {
    hideTyping();
    var wrap = el('div', 'sh-schat-msg is-assistant is-typing');
    wrap.id = 'sh-schat-typing';
    var bubble = el('div', 'sh-schat-bubble');
    bubble.appendChild(el('span', 'sh-schat-dots', '···'));
    bubble.appendChild(el('span', 'sh-sr-only', 'Support is checking the store data…'));
    wrap.appendChild(bubble);
    listEl.appendChild(wrap);
    keepInputVisible();
  }

  function hideTyping() {
    var t = document.getElementById('sh-schat-typing');
    if (t) { t.remove(); }
  }

  function start() {
    if (started) { return; }
    started = true;
    setStatus('Opening chat…');
    post('start', {}).then(function (data) {
      applyConversation(data);
      renderAll(data.messages);
      setStatus('');
      keepInputVisible();
    }).catch(function (err) {
      started = false;
      setStatus(errorText(err), true);
    });
  }

  function poll() {
    if (!isOpen || !convId) { return; }
    post('poll', { conversation_id: convId, after_id: lastId }).then(function (data) {
      var had = (data.messages || []).length > 0;
      applyConversation(data);
      renderAll(data.messages);
      if (had && document.hidden) { unread += data.messages.length; setBadge(); }
      if (had && !document.hidden) { keepInputVisible(); }
    }).catch(function () { /* keep quiet; next poll retries */ });
  }

  function startPolling() {
    stopPolling();
    pollTimer = window.setInterval(poll, 5000);
  }

  function stopPolling() {
    if (pollTimer) { window.clearInterval(pollTimer); pollTimer = null; }
  }

  /* ---- Launcher menu ---------------------------------------------------
     Three compact options above the launch button. The menu never replaces
     the chat: it only forwards "Live Chat" to open() below.
     ------------------------------------------------------------------- */
  function menuItems() {
    if (!menu) { return []; }
    return Array.prototype.slice.call(menu.querySelectorAll('[role="menuitem"]:not([aria-disabled="true"])'));
  }

  function openMenu(focusFirst) {
    if (!menu || menuOpen) { return; }
    menuOpen = true;
    if (menuHideTimer) { window.clearTimeout(menuHideTimer); menuHideTimer = null; }
    menu.hidden = false;
    menu.setAttribute('aria-hidden', 'false');
    fab.setAttribute('aria-expanded', 'true');
    // Flush the closed styles so the slide-up transition actually runs
    // instead of snapping straight to the open state.
    void menu.offsetWidth;
    menu.classList.add('is-open');
    if (focusFirst) {
      var items = menuItems();
      if (items.length) { items[0].focus(); }
    }
  }

  function closeMenu() {
    if (!menu || !menuOpen) { return; }
    menuOpen = false;
    // Move focus out BEFORE the menu leaves the accessibility tree, otherwise
    // aria-hidden would land on an element that still holds focus.
    if (menu.contains(document.activeElement)) { fab.focus(); }
    menu.classList.remove('is-open');
    menu.setAttribute('aria-hidden', 'true');
    fab.setAttribute('aria-expanded', 'false');
    if (menuHideTimer) { window.clearTimeout(menuHideTimer); }
    // Keep the node mounted for the reverse transition, then remove it from
    // the accessibility tree and the tab order entirely.
    menuHideTimer = window.setTimeout(function () {
      menuHideTimer = null;
      if (!menuOpen) { menu.hidden = true; }
    }, 240);
  }

  function toggleMenu() {
    if (menuOpen) { closeMenu(); } else { openMenu(true); }
  }

  function open() {
    closeMenu();
    isOpen = true;
    unread = 0; setBadge();
    syncViewport();
    // No inline top/left/bottom is written: CSS owns the fixed bottom anchor.
    // aria-expanded belongs to the launcher MENU (aria-controls), so opening
    // the panel leaves it collapsed; the dialog announces itself instead.
    sheet.hidden = false;
    start();
    startPolling();
    keepInputVisible();
    input.focus();
  }

  function close() {
    isOpen = false;
    sheet.hidden = true;
    stopPolling();
    fab.focus();
  }

  function send(text, clientId, pendingEl) {
    sendBtn.disabled = true;
    showTyping();
    return post('send', {
      conversation_id: convId, message: text, client_msg_id: clientId, after_id: lastId
    }).then(function (data) {
      hideTyping();
      if (pendingEl) { pendingEl.remove(); }
      applyConversation(data);
      renderAll(data.messages);
      setStatus('');
      keepInputVisible();
    }).catch(function (err) {
      hideTyping();
      setStatus(errorText(err), true);
      if (pendingEl) {
        pendingEl.classList.add('is-failed');
        var bubble = pendingEl.querySelector('.sh-schat-bubble');
        if (bubble && !bubble.querySelector('.sh-schat-retry')) {
          var retry = el('button', 'sh-schat-retry', 'Retry');
          retry.type = 'button';
          retry.addEventListener('click', function () { send(text, clientId, pendingEl); });
          bubble.appendChild(document.createElement('br'));
          bubble.appendChild(retry);
        }
      }
    }).then(function () { sendBtn.disabled = false; });
  }

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    var text = input.value.trim();
    if (!text || !convId) { return; }
    if (text.length > cfg.max) { setStatus('That message is too long (max ' + cfg.max + ' characters).', true); return; }
    sentOnce = true;
    suggestEl.textContent = '';
    var pending = renderMessage({ id: 0, kind: 'customer', body: text, at: new Date().toISOString() });
    if (pending) { pending.classList.add('is-pending'); }
    var clientId = newClientId();
    input.value = '';
    setStatus('');
    send(text, clientId, pending);
    input.focus();
  });

  input.addEventListener('keydown', function (e) {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); form.requestSubmit(); }
  });

  document.getElementById('sh-schat-new').addEventListener('click', function () {
    setStatus('Starting a new conversation…');
    post('new', {}).then(function (data) {
      listEl.textContent = ''; seen = {}; lastId = 0; sentOnce = false;
      applyConversation(data);
      renderAll(data.messages);
      setStatus('');
      input.focus();
    }).catch(function (err) { setStatus(errorText(err), true); });
  });

  handoffBtn.addEventListener('click', function () {
    if (!convId) { return; }
    setStatus('Connecting you with the support team…');
    post('handoff', { conversation_id: convId, client_msg_id: newClientId(), after_id: lastId }).then(function (data) {
      applyConversation(data);
      renderAll(data.messages);
      setStatus('');
      keepInputVisible();
    }).catch(function (err) { setStatus(errorText(err), true); });
  });

  // The launcher opens the support menu; it no longer jumps straight into the
  // chat. "Live Chat" in the menu is the single path into the existing panel.
  fab.addEventListener('click', function (e) {
    e.preventDefault();
    if (isOpen) { close(); return; }
    // No menu markup (an older cached partial) still opens the chat directly.
    if (!menu) { open(); return; }
    toggleMenu();
  });
  if (liveOpt) {
    liveOpt.addEventListener('click', function (e) {
      e.preventDefault();
      closeMenu();
      open();
    });
  }
  if (menu) {
    menu.addEventListener('keydown', function (e) {
      var items = menuItems();
      if (!items.length) { return; }
      var at = items.indexOf(document.activeElement);
      if (e.key === 'ArrowDown') { e.preventDefault(); items[(at + 1) % items.length].focus(); }
      else if (e.key === 'ArrowUp') { e.preventDefault(); items[(at - 1 + items.length) % items.length].focus(); }
      else if (e.key === 'Home') { e.preventDefault(); items[0].focus(); }
      else if (e.key === 'End') { e.preventDefault(); items[items.length - 1].focus(); }
      else if (e.key === 'Tab') { closeMenu(); }
    });
  }
  // A press anywhere outside the menu and the launcher closes it.
  document.addEventListener('pointerdown', function (e) {
    if (!menuOpen) { return; }
    var target = e.target;
    if ((menu && menu.contains(target)) || (fab && fab.contains(target))) { return; }
    closeMenu();
  }, true);
  document.getElementById('sh-schat-close').addEventListener('click', close);
  // Re-measure when the viewport changes. Plain page scrolling is deliberately
  // NOT listened to: a fixed panel must not move with the document.
  window.addEventListener('resize', function () { if (isOpen) { syncViewport(); } }, { passive: true });
  window.addEventListener('orientationchange', function () { if (isOpen) { syncViewport(); } }, { passive: true });
  if (window.visualViewport) {
    window.visualViewport.addEventListener('resize', function () { if (isOpen) { syncViewport(); } });
    window.visualViewport.addEventListener('scroll', function () { if (isOpen) { syncViewport(); } });
  }
  document.addEventListener('keydown', function (e) {
    if (e.key !== 'Escape') { return; }
    if (menuOpen) { closeMenu(); }
    if (isOpen) { close(); }
  });
  document.addEventListener('visibilitychange', function () {
    if (!document.hidden) { poll(); }
  });
})();
