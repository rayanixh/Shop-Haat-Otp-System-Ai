<?php
/**
 * Product detail page with gallery, tabs, reviews and related products.
 */
declare(strict_types=1);
require_once __DIR__ . '/config/config.php';
sh_require_installed();
require_once SH_ROOT . '/includes/catalog.php';
// The SEO helpers are used while this page builds its metadata, before
// includes/header.php is loaded, so the engine must be required here.
require_once SH_ROOT . '/includes/seo.php';
// The alt-text column is additive; ensure it exists before the row
// is read with SELECT * so the page can render it.
require_once SH_ROOT . '/includes/product-schema.php';
sh_product_schema_ensure();

$slug = sh_get('slug');
$product = $slug !== '' ? sh_product_by_slug($slug) : null;

if ($product === null) {
    http_response_code(404);
    $pageTitle = 'Product not found';
    require_once SH_ROOT . '/includes/header.php';
    echo '<div class="sh-wrap"><div class="sh-empty" style="margin-top:20px">'
        . '<span class="sh-empty__icon">' . sh_icon('box', 26) . '</span>'
        . '<h1 class="sh-empty__title">Product not found</h1>'
        . '<p class="sh-empty__text">This product may have been removed or is no longer available.</p>'
        . '<a class="sh-btn" href="' . e(sh_url('products.php')) . '">Continue shopping</a></div></div>';
    require_once SH_ROOT . '/includes/footer.php';
    exit;
}

$pid = (int)$product['id'];

// Review submission
$reviewError = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && sh_post('form') === 'review') {
    sh_csrf_require();
    $u = sh_user();
    if ($u === null) {
        sh_flash('error', 'Please sign in to write a review.');
        sh_redirect('login.php?redirect=' . urlencode('product.php?slug=' . $slug));
    }
    $rating = max(1, min(5, sh_int($_POST['rating'] ?? 5, 5)));
    $title = mb_substr(sh_post('title'), 0, 150);
    $body = mb_substr(sh_post('body'), 0, 2000);
    if (mb_strlen($body) < 8) {
        $reviewError = 'Please write at least a few words about the product.';
    } else {
        try {
            $already = sh_one('SELECT id FROM reviews WHERE product_id = ? AND user_id = ? LIMIT 1', [$pid, (int)$u['id']]);
            if ($already) {
                $reviewError = 'You have already reviewed this product.';
            } else {
                sh_insert('reviews', [
                    'product_id' => $pid, 'user_id' => (int)$u['id'], 'author_name' => $u['name'],
                    'rating' => $rating, 'title' => $title, 'body' => $body, 'status' => 'approved',
                ]);
                sh_query('UPDATE products SET
                    rating = COALESCE((SELECT ROUND(AVG(r.rating),2) FROM reviews r WHERE r.product_id = ? AND r.status = \'approved\'),0),
                    review_count = (SELECT COUNT(*) FROM reviews r WHERE r.product_id = ? AND r.status = \'approved\')
                    WHERE id = ?', [$pid, $pid, $pid]);
                sh_flash('success', 'Thank you — your review has been published.');
                sh_redirect('product.php?slug=' . urlencode($slug));
            }
        } catch (Throwable $e) {
            sh_log_exception($e, 'review');
            $reviewError = 'Your review could not be saved. Please try again.';
        }
    }
}

try { sh_query('UPDATE products SET view_count = view_count + 1 WHERE id = ?', [$pid]); }
catch (Throwable $e) { sh_log_exception($e, 'view-count'); }

// Only real, existing files are shown. The legacy products.image is a
// primary-image snapshot and doubles as a fallback for older installations.
$galleryRows = sh_product_gallery_rows($pid, (string)($product['image'] ?? ''));
$gallery = array_values(array_filter($galleryRows, static fn(array $r): bool => $r['url'] !== ''));
$catalog = sh_product_catalog_display($pid, $product);
$reviews = sh_all('SELECT * FROM reviews WHERE product_id = ? AND status = \'approved\' ORDER BY created_at DESC LIMIT 20', [$pid]);
$related = sh_products_related($pid, $product['category_id'] ? (int)$product['category_id'] : null, 6);
$shWishlist = sh_wishlist_ids();

$off = sh_discount_percent($product['price'], $product['compare_price']);
$stock = (int)$product['stock'];
// Digital products were fulfilled by the code-delivery feature that has been
// removed. Their rows are left untouched, but they must not take an order the
// store can no longer fill, so they are shown as not orderable online.
$isPhysical = (string)($product['product_type'] ?? 'physical') === 'physical';
$orderable  = $isPhysical && $stock > 0;

/*
 * SEO. The product row carries the owner's custom title, description, keywords,
 * social image, canonical override and noindex flag, so the whole row is handed
 * to the SEO engine and the generated values below are only fallbacks.
 *
 * The canonical always uses the slug form. Filter, sort and tracking parameters
 * are dropped by sh_seo_canonical_url(), so one product has exactly one indexable
 * URL no matter how a shopper arrived at it.
 */
$pageSeoKey     = 'product';
$pageSeoEntity  = $product;
$pageOgType     = 'product';
$pageImage      = sh_seo_product_image($product);
$pageTitle      = (string)$product['name'];
$pageDescription = sh_seo_plain((string)($product['short_description'] ?: $product['description']));
$pageCanonical  = 'product.php?slug=' . rawurlencode((string)$product['slug']);
$pageKeywords   = trim((string)($product['seo_focus_keyword'] ?? '') . ',' . (string)($product['meta_keywords'] ?? ''), ',');

// Breadcrumbs mirror the navigation the shopper actually sees on the page.
$pageBreadcrumbs = [['name' => 'Home', 'url' => 'index.php']];
if (!empty($product['category_name']) && !empty($product['category_slug'])) {
    $pageBreadcrumbs[] = [
        'name' => (string)$product['category_name'],
        'url'  => 'category.php?slug=' . rawurlencode((string)$product['category_slug']),
    ];
}
$pageBreadcrumbs[] = ['name' => (string)$product['name'], 'url' => ''];

// Gallery images join the structured data so image results show the real
// product photography rather than a stock placeholder.
$galleryImages = [];
foreach ($gallery as $imgRow) {
    $galleryImages[] = 'uploads/products/' . rawurlencode(basename((string)$imgRow['file']));
}

// Resolve the metadata first, then build the Product node against the final
// canonical URL so the JSON-LD and the <link rel="canonical"> can never disagree.
$shProductMeta = sh_seo_meta([
    'key' => 'product',
    'entity' => $product,
    'fallback_title' => (string)$product['name'],
    'fallback_desc' => $pageDescription,
    'canonical' => $pageCanonical,
    'image' => $pageImage,
    'type' => 'product',
    'keywords' => $pageKeywords,
    'breadcrumbs' => $pageBreadcrumbs,
]);
$structuredData = sh_seo_product_schema($product, $shProductMeta, $galleryImages);

$descriptionText = trim((string)($product['description'] ?: $product['short_description'] ?: ''));
$specLines = array_values(array_filter(array_map('trim', explode("\n", (string)($product['specifications'] ?? '')))));
$reviewCount = (int)$product['review_count'];
$soldCount = (int)$product['sold_count'];
$canWriteReview = sh_user() !== null || $reviewError !== '';
$tabList = [];
if ($descriptionText !== '') { $tabList[] = ['id' => 'desc', 'label' => 'Description']; }
if ($specLines !== []) { $tabList[] = ['id' => 'specs', 'label' => 'Specifications']; }
if ($reviews !== [] || $canWriteReview) {
    $tabList[] = ['id' => 'reviews', 'label' => $reviewCount > 0 ? 'Reviews (' . $reviewCount . ')' : 'Write a review'];
}
$firstTab = $tabList !== [] ? $tabList[0]['id'] : '';

require_once SH_ROOT . '/includes/header.php';
?>
<div class="sh-wrap">
  <nav class="sh-breadcrumb" aria-label="Breadcrumb">
    <a href="<?= e(sh_url('index.php')) ?>">Home</a> <?= sh_icon('chevron-right', 13) ?>
    <?php if ($product['category_slug']): ?>
      <a href="<?= e(sh_url('category.php?slug=' . urlencode($product['category_slug']))) ?>"><?= e($product['category_name']) ?></a>
      <?= sh_icon('chevron-right', 13) ?>
    <?php endif; ?>
    <span aria-current="page"><?= e(sh_excerpt($product['name'], 60)) ?></span>
  </nav>

  <div class="sh-pdp<?= $gallery === [] ? ' sh-pdp--no-gallery' : '' ?>">
    <?php if ($gallery !== []): ?>
    <!-- Manual gallery: no timer, no autoplay, no automatic slide -->
    <div data-gallery>
      <div class="sh-gallery__main" data-gallery-stage>
        <img data-gallery-main src="<?= e($gallery[0]['url']) ?>"
             alt="<?= e(trim((string)($product['image_alt'] ?? '')) !== '' ? (string)$product['image_alt'] : (string)$product['name']) ?>">
      </div>
      <?php if (count($gallery) > 1): ?>
        <div class="sh-gallery__toolbar">
          <div class="sh-gallery__nav">
            <button class="sh-gallery__nav-btn" type="button" data-gallery-prev aria-label="Previous image"><?= sh_icon('chevron-left', 16) ?></button>
            <span class="sh-gallery__count" data-gallery-count>1 / <?= count($gallery) ?></span>
            <button class="sh-gallery__nav-btn" type="button" data-gallery-next aria-label="Next image"><?= sh_icon('chevron-right', 16) ?></button>
          </div>
        </div>
        <div class="sh-gallery__thumbs" aria-label="Product images">
          <?php foreach ($gallery as $i => $g): ?>
            <?php $galleryAlt = trim((string)($product['image_alt'] ?? '')) !== ''
                ? (string)$product['image_alt'] . ' — image ' . ($i + 1)
                : (string)$product['name'] . ' — image ' . ($i + 1); ?>
            <button class="sh-gallery__thumb <?= $i === 0 ? 'sh-gallery__thumb--on' : '' ?>" type="button"
                    data-gallery-thumb="<?= e($g['url']) ?>" data-gallery-alt="<?= e($galleryAlt) ?>"
                    aria-label="View image <?= $i + 1 ?>" aria-pressed="<?= $i === 0 ? 'true' : 'false' ?>">
              <img src="<?= e($g['url']) ?>" alt="" loading="lazy">
            </button>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>
    <?php endif; ?>

    <!-- Buy box -->
    <div>
      <h1 class="sh-pdp__title"><?= e($product['name']) ?></h1>
      <?php if ($reviewCount > 0 || $soldCount > 0): ?>
        <div class="sh-pdp__meta">
          <?php if ($reviewCount > 0): ?>
            <?= sh_stars((float)$product['rating'], $reviewCount) ?>
            <span><?= $reviewCount ?> review<?= $reviewCount === 1 ? '' : 's' ?></span>
          <?php endif; ?>
          <?php if ($soldCount > 0): ?><span><?= $soldCount ?> sold</span><?php endif; ?>
        </div>
      <?php endif; ?>

      <div class="sh-pdp__price">
        <span class="sh-pdp__now"><?= e(sh_money($product['price'])) ?></span>
        <?php if ($off > 0): ?>
          <span class="sh-pdp__was"><?= e(sh_money($product['compare_price'])) ?></span>
          <span class="sh-pdp__off">Save <?= $off ?>%</span>
        <?php endif; ?>
      </div>

      <dl class="sh-pdp__rows">
        <div class="sh-pdp__row"><dt>Availability</dt><dd>
          <?php if (!$isPhysical): ?><span class="sh-badge sh-badge--warn"><?= sh_icon('info', 13) ?> Not orderable online</span>
          <?php elseif ($stock <= 0): ?><span class="sh-badge sh-badge--bad"><?= sh_icon('x-circle', 13) ?> Out of stock</span>
          <?php elseif ($stock <= 10): ?><span class="sh-badge sh-badge--warn"><?= sh_icon('clock', 13) ?> Only <?= $stock ?> left</span>
          <?php else: ?><span class="sh-badge sh-badge--ok"><?= sh_icon('check-circle', 13) ?> In stock</span><?php endif; ?>
        </dd></div>
        <div class="sh-pdp__row"><dt>Delivery</dt><dd>
          Inside city <?= e(sh_money(sh_setting('delivery_fee_inside', '60'))) ?> ·
          Outside city <?= e(sh_money(sh_setting('delivery_fee_outside', '120'))) ?>
        </dd></div>
        <?php if ($catalog['brand'] !== ''): ?>
          <div class="sh-pdp__row"><dt>Brand</dt><dd><?= e($catalog['brand']) ?></dd></div>
        <?php endif; ?>
        <?php if ($catalog['type'] !== ''): ?>
          <div class="sh-pdp__row"><dt>Product type</dt><dd><?= e($catalog['type']) ?></dd></div>
        <?php endif; ?>
        <?php if ($product['sku']): ?>
          <div class="sh-pdp__row"><dt>SKU</dt><dd><?= e($product['sku']) ?></dd></div>
        <?php endif; ?>
      </dl>

      <?php if ($catalog['colours'] !== []): ?>
        <fieldset class="sh-pdp__option">
          <legend class="sh-pdp__option-label">Available colours</legend>
          <div class="sh-pdp__colour-list">
            <?php foreach ($catalog['colours'] as $i => $colour): ?>
              <label class="sh-pdp__colour">
                <input type="radio" name="product_colour" value="<?= e($colour['value']) ?>"
                       data-product-colour data-colour-name="<?= e($colour['name']) ?>" <?= $i === 0 ? 'checked' : '' ?>>
                <span class="sh-pdp__swatch" style="background:<?= e($colour['hex']) ?>"></span>
                <span><?= e($colour['name']) ?></span>
              </label>
            <?php endforeach; ?>
          </div>
          <div class="sh-pdp__selected-colour">Selected: <strong data-product-colour-label><?= e($catalog['colours'][0]['name']) ?></strong></div>
        </fieldset>
      <?php endif; ?>

      <?php if ($orderable): ?>
        <div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap">
          <span style="font-size:13px;font-weight:700;color:var(--sh-ink-2)">Quantity</span>
          <div class="sh-qty">
            <button type="button" data-qty-step="-1" aria-label="Decrease quantity"><?= sh_icon('minus', 15) ?></button>
            <input id="sh-pdp-qty" type="number" value="1" min="1" max="<?= min(20, $stock) ?>" aria-label="Quantity">
            <button type="button" data-qty-step="1" aria-label="Increase quantity"><?= sh_icon('plus', 15) ?></button>
          </div>
          <span style="font-size:12.5px;color:var(--sh-muted)"><?= $stock ?> available</span>
        </div>
      <?php endif; ?>

      <div class="sh-pdp__buy">
        <button class="sh-btn sh-btn--lg" type="button" data-add-cart="<?= $pid ?>" data-qty-source="sh-pdp-qty" <?= $orderable ? '' : 'disabled' ?>>
          <?= sh_icon('shopping-cart', 17) ?> Add to Cart
        </button>
        <button class="sh-btn sh-btn--lg sh-btn--dark" type="button" data-add-cart="<?= $pid ?>" data-qty-source="sh-pdp-qty" data-then-checkout <?= $orderable ? '' : 'disabled' ?>>
          <?= sh_icon('zap', 17) ?> Buy Now
        </button>
        <button class="sh-btn sh-btn--lg sh-btn--ghost" type="button" data-wishlist="<?= $pid ?>"
                aria-pressed="<?= in_array($pid, $shWishlist, true) ? 'true' : 'false' ?>">
          <?= sh_icon('heart', 17) ?> Wishlist
        </button>
      </div>

      <?php if (!$isPhysical): ?>
        <div class="sh-alert sh-alert--info"><?= sh_icon('info', 16) ?>
          <span>This item can no longer be ordered online. Please contact our support team if you need it.</span></div>
      <?php endif; ?>

      <?php if ($reviews === [] && $canWriteReview === false): ?>
        <p class="sh-table__meta" style="margin-top:10px">
          <a href="<?= e(sh_url('login.php?redirect=' . urlencode('product.php?slug=' . $slug))) ?>" style="color:var(--sh-brand);font-weight:700">Sign in to write a review</a>
        </p>
      <?php endif; ?>

      <div class="sh-secure-note">
        <?= sh_icon('shield', 16) ?>
        <span>Secure checkout with bKash, Nagad, Rocket and Cash on Delivery. Your payment details are never stored on our servers.</span>
      </div>
    </div>
  </div>

  <?php if ($tabList !== []): ?>
    <!-- Only sections with real content are rendered: no empty tabs or labels. -->
    <div class="sh-pdp__tabs" data-tabs>
      <div class="sh-tabs__head" role="tablist">
        <?php foreach ($tabList as $i => $tab): ?>
          <button class="sh-tabs__btn <?= $i === 0 ? 'sh-tabs__btn--on' : '' ?>" type="button"
                  role="tab" data-tab="<?= e($tab['id']) ?>" aria-selected="<?= $i === 0 ? 'true' : 'false' ?>"><?= e($tab['label']) ?></button>
        <?php endforeach; ?>
      </div>

      <?php if ($descriptionText !== ''): ?>
        <div class="sh-tabs__panel" data-tab-panel="desc" role="tabpanel" <?= $firstTab !== 'desc' ? 'hidden' : '' ?>>
          <?= nl2br(e($descriptionText)) ?>
        </div>
      <?php endif; ?>

      <?php if ($specLines !== []): ?>
        <div class="sh-tabs__panel" data-tab-panel="specs" role="tabpanel" <?= $firstTab !== 'specs' ? 'hidden' : '' ?>>
          <table class="sh-spectable"><tbody>
            <?php foreach ($specLines as $line): $parts = explode(':', $line, 2); ?>
              <tr>
                <td><?= e(trim($parts[0])) ?></td>
                <td><?= e(trim($parts[1] ?? '')) ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody></table>
        </div>
      <?php endif; ?>

      <?php if ($reviews !== [] || $canWriteReview): ?>
        <div class="sh-tabs__panel" data-tab-panel="reviews" role="tabpanel" <?= $firstTab !== 'reviews' ? 'hidden' : '' ?>>
          <?php if ($reviewError): ?>
            <div class="sh-alert sh-alert--error"><?= sh_icon('x-circle', 16) ?><span><?= e($reviewError) ?></span></div>
          <?php endif; ?>

          <?php foreach ($reviews as $rv): ?>
            <div class="sh-review">
              <div class="sh-review__head">
                <span class="sh-review__author"><?= e($rv['author_name']) ?></span>
                <?= sh_stars((float)$rv['rating']) ?>
                <span class="sh-review__date"><?= e(date('d M Y', strtotime($rv['created_at']))) ?></span>
              </div>
              <?php if ($rv['title']): ?><p class="sh-review__title"><?= e($rv['title']) ?></p><?php endif; ?>
              <p class="sh-review__body"><?= nl2br(e($rv['body'])) ?></p>
            </div>
          <?php endforeach; ?>

          <?php if (sh_user() === null): ?>
            <?php if ($reviews !== []): ?>
              <p style="font-size:13.5px;color:var(--sh-muted);margin-top:16px">
                Please <a href="<?= e(sh_url('login.php?redirect=' . urlencode('product.php?slug=' . $slug))) ?>" style="color:var(--sh-brand);font-weight:700">sign in</a> to write a review.
              </p>
            <?php endif; ?>
          <?php else: ?>
            <div style="<?= $reviews !== [] ? 'margin-top:20px;padding-top:18px;border-top:1px solid var(--sh-line)' : '' ?>">
              <h3 style="font-size:14.5px;font-weight:800;margin-bottom:12px">Write a review</h3>
              <form method="post">
                <?= sh_csrf_field() ?>
                <input type="hidden" name="form" value="review">
                <div class="sh-grid2">
                  <div class="sh-field">
                    <label class="sh-field__label" for="rv-rating">Your rating</label>
                    <select class="sh-select" id="rv-rating" name="rating">
                      <?php for ($i = 5; $i >= 1; $i--): ?>
                        <option value="<?= $i ?>"><?= $i ?> star<?= $i === 1 ? '' : 's' ?></option>
                      <?php endfor; ?>
                    </select>
                  </div>
                  <div class="sh-field">
                    <label class="sh-field__label" for="rv-title">Review title</label>
                    <input class="sh-input" id="rv-title" name="title" maxlength="150" placeholder="Summarise your experience">
                  </div>
                </div>
                <div class="sh-field">
                  <label class="sh-field__label" for="rv-body">Your review <span class="sh-field__req">*</span></label>
                  <textarea class="sh-textarea" id="rv-body" name="body" required minlength="8" maxlength="2000"
                            placeholder="What did you like or dislike about this product?"></textarea>
                </div>
                <button class="sh-btn" type="submit"><?= sh_icon('send', 15) ?> Submit review</button>
              </form>
            </div>
          <?php endif; ?>
        </div>
      <?php endif; ?>
    </div>
  <?php endif; ?>

  <?php if ($related): ?>
    <section class="sh-section" style="margin-top:14px">
      <div class="sh-section__head">
        <h2 class="sh-section__title"><?= sh_icon('layout', 19) ?> Related Products</h2>
      </div>
      <div class="sh-product-grid">
        <?php foreach ($related as $p) { include SH_ROOT . '/includes/product-card.php'; } ?>
      </div>
    </section>
  <?php endif; ?>
</div>
<?php require_once SH_ROOT . '/includes/footer.php'; ?>
